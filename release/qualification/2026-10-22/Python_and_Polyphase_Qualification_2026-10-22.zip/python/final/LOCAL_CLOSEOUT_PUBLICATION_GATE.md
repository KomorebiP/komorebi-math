# Block 21 Publication Gate

Status: **PASSED**

Package version: `1.0.0b4`  
Mode: `full`  
Generated: `2026-10-22T14:01:58Z`

## Checks

| Check | Result | Detail |
|---|---:|---|
| version and citation identity | **PASS** | pyproject, runtime, and citation identify 1.0.0b4 |
| repository publication layout | **PASS** | 16 publication-facing files present |
| archive path safety | **PASS** | all source-tree paths are archive safe |
| strict research API contract | **PASS** | strict API passed |
| strict beta API contract | **PASS** | beta API passed |
| strict stable API contract | **PASS** | stable API passed |
| stable verification suite | **PASS** | 6/6 |
| Block 20 verification suite | **PASS** | 47/47 |
| current beta release contract | **PASS** | release contract passed |
| cross-version upgrade contract | **PASS** | upgrade contract passed |
| executed platform evidence | **PASS** | beta evidence passed |
| public beta readiness | **PASS** | beta readiness passed |
| deterministic public capability tour | **PASS** | capability record 0e20e32f4ad9004d5248d258813b6acfec7b9e96cc30c001aa6865aba9039fdf |
| local documentation links | **PASS** | all local Markdown links resolve |
| current distribution parity and executable modes | **PASS** | 1.0.0b4-repair-r4-block21: 393 source files match both distributions, wheel RECORD and shell modes pass |
| strict MkDocs build | **PASS** | strict MkDocs build passed |
| complete source test suite | **PASS** | 2733 passed, 7 skipped, 6 warnings in 117.86s (0:01:57) |
| source and artifact snapshot unchanged during qualification | **PASS** | 27375fa6936716ca7f0fa4a512f1d35c3ebfdf90548d39c3c0c8e00d8ffa6136 |

## Non-gating warnings

- Installed-artifact behavior was not executed; use --installed-artifacts or release_artifact_gate.py.

## Public capability tour

Record digest: `0e20e32f4ad9004d5248d258813b6acfec7b9e96cc30c001aa6865aba9039fdf`

The tour covers polyphase refinement, redundant analysis and synthesis, Euler–Fibonacci coordinates, exact finite integration, typed expressions, portable persistence, and the frozen stable API manifest.

## Full source tests

- Return code: `0`
- Summary: `2733 passed, 7 skipped, 6 warnings in 117.86s (0:01:57)`

Report SHA-256: `bd1b069f7c60e6a0413979df157013855b8f220684ef0fb6ca87c1569025be92`
