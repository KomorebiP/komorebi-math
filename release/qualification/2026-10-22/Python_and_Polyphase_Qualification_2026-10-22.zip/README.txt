PYTHON AND POLYPHASE QUALIFICATION
22 October 2026

The implementation changes are in these private GitHub pull requests:
Python: https://github.com/KomorebiP/komorebi-math/pull/1
C: https://github.com/KomorebiP/polyphase-float/pull/2

GITHUB_PROVENANCE.json records the exact commits and source trees.
This archive contains reports and execution evidence. Source and distributions
are retained in the linked repositories and Actions artifacts.

PYTHON: KOMOREBI MATH 1.0.0b4

Repairs prevent tiny, unsigned and mixed-type reconstruction errors from being
accepted by polyphase certificates. Release-stage parsing and promotion review
now validate the exact source, artifacts and evidence. The stable API remains
131 symbols. Original software/documentation are MIT licensed; third-party
notices and separate data terms are preserved.

Local source qualification passed 2,733 tests with seven optional-backend skips
and six recorded warnings. A separate pinned JAX/PyTorch CPU campaign passed
all seven of those exact skipped case identities; its comparison proof is
included. Strict MkDocs, API/stable verification and all 64 manual examples pass.
Six base stress campaigns passed 351 checks plus 11 resource controls.

The original and sdist-rebuilt wheels each passed 1,556 installed tests across
91 files, with zero skips/failures/errors in isolated offline environments.
The fresh hosted Linux/Windows Python 3.11/3.12/3.13 matrix passed the same
installed checks for both wheels on all six targets. Its nested records were
revalidated against the exact local checkout. The common hosted wheel has the
same SHA-256 as the local build:
b0848c2d8e77fe4376ecc81e0ec3cf7954653c64d46c7b6950480e8c8230b787

No NVIDIA GPU execution is established. A newly qualified tagged RC and the
recorded real NVIDIA hardware evidence remain final-release requirements.
The RC sandbox evidence demonstrates integration only.

C: POLYPHASE FLOAT 0.20.0

Repairs bound FPIF resources, check the exact Airy boundary and reject invalid
rounding modes before mutation. All 79 indexed allocation-evidence gaps are
closed within their documented scope; GMP/libc internal allocations are not
claimed to be covered by the library allocator controls. LGPL terms, ABI
epoch 1 and the existing SONAME are preserved.

GCC, Clang and OpenMP each passed 69/69 configured checks. ASan/UBSan passed
26/26 hardening checks. Two 601-second fuzz campaigns completed 50,588,205
executions without a crash or diagnostic. All 13 examples, clean-source
regressions, unchanged-binary replay and export/independence audits passed.
Hosted PR CI, ABI and CodeQL concluded successfully; CodeQL SARIF has zero
results. Hosted ThreadSanitizer and concurrency stress passed. The PR merge
and branch head have exactly the qualified 672-file source tree.

Independent correctness reproduction and mathematical review remain 1.0
promotion gates. Wider platform or longer-running fuzz claims need their own
evidence.

STATUS AND EVIDENCE

Hosted snapshots retain actual run/job status and observation timestamps.
Some duplicate workflow runs or post-processing statuses were still in
progress at the last observation; passing test records are distinguished from
those lifecycle states. The GitHub links show live status.

Earlier failed integration/qualification attempts are retained. In particular,
the original pytest 9 full-source XML was discarded by the preceding wrapper
on parse failure; its original raw XML cannot be recovered from that attempt.
The repaired wrapper retains failed XML. Pytest 8.4.2 gives consistent concrete
JUnit case counts while executing and failing unittest subtests correctly.

SHA256SUMS covers every other file in this evidence archive. These hashes bind
bytes; they do not by themselves establish authorship or external review.
