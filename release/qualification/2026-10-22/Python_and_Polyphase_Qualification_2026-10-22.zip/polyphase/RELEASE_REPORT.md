# Polyphase Float release candidate

Version 0.20.0 integrates the PPFIF resource fix and corrects exact Airy
domain admission and floating-setter validation. It closes all 79 indexed
allocation-evidence entries through source review and targeted tests.
The partition is 63 allocation-free valid-input paths, 12 initialization
lifecycles, two prefix-cleanup contracts and two additional transactional
wrappers. The total transactional class is 192.

The source directory is polyphase-float-0.20.0/. The existing
LGPL-3.0-or-later license, ABI epoch 1 and SONAME are retained.

## Fresh validation

| Configuration | Passing checks |
| --- | ---: |
| gcc-serial | 69/69 |
| clang-serial | 69/69 |
| gcc-openmp | 69/69 |
| asan | 26/26 |

The sanitizer scope excludes the Python ctypes export check. All ordinary
compiler suites run that check. LeakSanitizer is explicitly disabled.
Exact project allocator balance is separate from GMP allocation behavior.

Both Clang libFuzzer targets ran a requested 600-second campaign. Text parsing
completed 1,994,599 executions and PPFIF import
completed 48,593,606 executions without a sanitizer
diagnostic or crash. Actual durations and seeds are recorded in the receipts.
These are bounded campaigns rather than exhaustive or continuous fuzzing.

All 13 examples passed. An unchanged binary built against pristine 0.19.0
produced identical checked output with the candidate library. The clean source
archive built through Make and passed the three added regressions. The
compiled release audit confirmed 437 enabled GCC exports and zero production
MPFR imports. The targeted branch matrix passed 515 checks.

## Reproduction

From the source directory run:

    python3 tools/qualify_release.py --output ../qualification --with-sanitizers

The source archive and both final qualification receipts bind the same
672-file snapshot. Source files were unchanged during
qualification. Commands, logs, dependency versions, source hashes and
generated minimized fuzz corpora are preserved under validation/.

Source snapshot SHA-256: 20a87a41770a9573a654f0807662f99834b98009aa9e25150ca9b68f73f17c4f

## Corrected failures retained

The preflight audit caught generated contracts that became stale after new
documentation was added, and a semantic negative-control fixture missing
its required section field. Regeneration and a complete fixture corrected
both. Inherited remote export fixtures were adapted to the centralized
capability helper's newer error wording while retaining the rejection cases.

The first qualification launch incorrectly parsed blank lines into CMake
cache keys, so installed official MPFR headers appeared missing. A line parser
and three regression tests fixed this. The failed launch and interrupted
companion fuzz campaign are preserved as superseded evidence and excluded
from the final passing matrix. Earlier targeted harness corrections and a
corrected strict-warning failure are retained in the source evidence.
An initial cross-session process-stop attempt could not address the target
PID. The superseded fuzz session was then interrupted through its session
handle. The first handoff-helper patch had malformed patch formatting, failed
before writing a file, and was corrected before packaging.

## Promotion boundary

This is a pre-1.0 candidate. Independent external correctness reproduction
and mathematical review remain open. Same-host compiler variation does not
establish external replication. Numerical caps and certification budgets remain
explicit. There is no universal correct-rounding, broad native-platform or new
performance claim.

The remote baseline was inspected. All 47 production files matched the older
0.18.0 source manifest. Remote CI, private CodeQL and export-audit work were
preserved while the audited 0.19.0 source became the new production baseline.
No public GitHub release or tag is asserted by this package.
