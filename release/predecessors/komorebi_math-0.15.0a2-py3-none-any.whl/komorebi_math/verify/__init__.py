"""Installed package verification entry points."""

from .algorithms import run_algorithms_verification
from .analytic import run_analytic_verification
from .arithmetic import run_arithmetic_verification
from .core import VerificationCheck, VerificationReport, run_core_verification
from .dsp import run_dsp_verification
from .dynamics import run_dynamics_verification
from .export import run_export_verification
from .generating import run_generating_verification
from .coordinates import run_coordinates_verification
from .deformation import run_deformation_verification
from .nonlinear import run_nonlinear_foundation_verification, run_nonlinear_verification
from .nonlinear_advanced import run_advanced_nonlinear_verification
from .scalable_nonlinear import run_scalable_nonlinear_verification
from .streaming_beta import run_streaming_beta_verification
from .refinement import run_refinement_verification
from .signals import run_signals_verification
from .sequences import run_sequences_verification
from .quantum import run_quantum_verification
from .langlands import (
    run_langlands_completion_verification,
    run_langlands_finite_image_verification,
    run_langlands_local_verification,
    run_langlands_verification,
)


def run_block2_verification() -> VerificationReport:
    """Run the core, refinement, and nonlinear foundation suites."""

    reports = (run_core_verification(), run_refinement_verification(), run_nonlinear_foundation_verification())
    return VerificationReport(tuple(check for report in reports for check in report.checks))


def run_block3_verification() -> VerificationReport:
    """Run every implemented suite through the structured algorithms block."""

    reports = (run_block2_verification(), run_algorithms_verification())
    return VerificationReport(tuple(check for report in reports for check in report.checks))


def run_block4_verification() -> VerificationReport:
    """Run every implemented suite through signals, probability, and memory."""

    reports = (run_block3_verification(), run_signals_verification(), run_dynamics_verification())
    return VerificationReport(tuple(check for report in reports for check in report.checks))


def run_block5_verification() -> VerificationReport:
    """Run every implemented suite through analytic and finite quantum domains."""

    reports = (run_block4_verification(), run_analytic_verification(), run_quantum_verification())
    return VerificationReport(tuple(check for report in reports for check in report.checks))


def run_block6_verification() -> VerificationReport:
    """Run every implemented suite through local arithmetic and sequences."""

    reports = (run_block5_verification(), run_arithmetic_verification(), run_sequences_verification())
    return VerificationReport(tuple(check for report in reports for check in report.checks))


def run_block7_verification() -> VerificationReport:
    """Run every implemented suite through deformation and finite Langlands models."""

    reports = (run_block6_verification(), run_deformation_verification(), run_langlands_verification())
    return VerificationReport(tuple(check for report in reports for check in report.checks))


def run_block8_verification() -> VerificationReport:
    """Run every implemented suite through portable export and LaTeX output."""

    reports = (run_block7_verification(), run_export_verification())
    return VerificationReport(tuple(check for report in reports for check in report.checks))


def run_block9_verification() -> VerificationReport:
    """Run every implemented suite through advanced nonlinear integration."""

    reports = (run_block8_verification(), run_advanced_nonlinear_verification())
    return VerificationReport(tuple(check for report in reports for check in report.checks))


def run_block10_verification() -> VerificationReport:
    """Run every implemented suite through scalable nonlinear hardening."""

    reports = (run_block9_verification(), run_scalable_nonlinear_verification())
    return VerificationReport(tuple(check for report in reports for check in report.checks))


def run_block11_verification() -> VerificationReport:
    """Run every implemented suite through streaming persistence and beta contracts."""

    reports = (run_block10_verification(), run_streaming_beta_verification())
    return VerificationReport(tuple(check for report in reports for check in report.checks))


def run_block12_verification() -> VerificationReport:
    """Run every implemented suite through the production DSP expansion."""

    reports = (run_block11_verification(), run_dsp_verification())
    return VerificationReport(tuple(check for report in reports for check in report.checks))


def run_block13_verification() -> VerificationReport:
    """Run every implemented suite through normalized generating functions."""

    reports = (run_block12_verification(), run_generating_verification())
    return VerificationReport(tuple(check for report in reports for check in report.checks))


def run_block14_verification() -> VerificationReport:
    """Run every implemented suite through exact coordinate changes."""

    reports = (run_block13_verification(), run_coordinates_verification())
    return VerificationReport(tuple(check for report in reports for check in report.checks))


__all__ = [
    "run_langlands_verification",
    "run_langlands_local_verification",
    "run_langlands_finite_image_verification",
    "run_langlands_completion_verification",
    "run_deformation_verification",
    "run_export_verification",
    "run_block7_verification",
    "run_block8_verification",
    "run_block9_verification",
    "run_block10_verification",
    "run_block11_verification",
    "run_block12_verification",
    "run_block13_verification",
    "run_block14_verification",
    "run_coordinates_verification",
    "run_generating_verification",
    "run_dsp_verification",
    "run_scalable_nonlinear_verification",
    "run_streaming_beta_verification",
    "run_advanced_nonlinear_verification",
    "run_nonlinear_foundation_verification",
    "VerificationCheck",
    "VerificationReport",
    "run_algorithms_verification",
    "run_arithmetic_verification",
    "run_analytic_verification",
    "run_block2_verification",
    "run_block3_verification",
    "run_block4_verification",
    "run_block5_verification",
    "run_block6_verification",
    "run_core_verification",
    "run_dynamics_verification",
    "run_nonlinear_verification",
    "run_refinement_verification",
    "run_quantum_verification",
    "run_signals_verification",
    "run_sequences_verification",
]
