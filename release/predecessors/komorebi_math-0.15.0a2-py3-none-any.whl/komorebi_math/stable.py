"""Curated 1.0-candidate API for Komorebi Math.

The complete package remains available for research use.  This namespace is the
smaller compatibility surface intended to survive the final 1.0 freeze.  Block
15 concentrates on finite polyphase refinement, certified reconstruction, and
portable records while retaining the general packet-refinement primitives.
"""

from ._version import __version__
from .arithmetic.polyphase import (
    ArithmeticPolyphase,
    mahler_polyphase,
    mixed_radix_address as arithmetic_mixed_radix_address,
    mixed_radix_digits as arithmetic_mixed_radix_digits,
    polyphase_analyze as arithmetic_polyphase_analyze,
    polyphase_synthesize as arithmetic_polyphase_synthesize,
)
from .certificates import Certificate, ComputationResult, ConditionalResult, Exactness
from .compatibility import (
    STABLE_API_STABILITY_LEVEL,
    STABLE_PUBLIC_NAMESPACES,
    ApiCompatibilityReport,
    PublicApiManifest,
    PublicApiSymbol,
    check_stable_api,
    create_stable_api_manifest,
    load_stable_api_manifest,
)
from .core.packets import PacketCoordinates, PacketSystem
from .exceptions import (
    AssumptionError,
    BackendUnavailableError,
    DimensionError,
    ExactnessError,
    KomorebiMathError,
    ResourceLimitError,
    ValidationError,
)
from .export.persistence import (
    PORTABLE_SCHEMA,
    PORTABLE_SCHEMA_VERSION,
    PortableCodec,
    PortableMigration,
    dumps_portable,
    from_portable_data,
    load_portable,
    loads_portable,
    portable_codecs,
    portable_digest,
    portable_migrations,
    save_portable,
    to_portable_data,
)
from .refinement.polyphase import (
    LatticePolyphaseRefinement,
    PolyphaseCoordinateRecord,
    PolyphaseRefinement,
    PolyphaseRefinementTower,
    coarsen_lattice_polyphase,
    coarsen_polyphase,
    polyphase_refinement_certificate,
    refine_lattice_polyphase,
    refine_polyphase,
)
from .refinement.residue import (
    ResidueCoordinates,
    nested_residue_address,
    nested_residue_analysis,
    residue_analyze,
    residue_synthesize,
)
from .refinement.towers import PacketRefinement, RefinementTower, common_refinement
from .signals.polyphase import (
    LatticePolyphaseCoordinates,
    PolyphaseCoordinates,
    PolyphaseSystem,
    lattice_polyphase_analyze,
    lattice_polyphase_synthesize,
    polyphase_analyze as signal_polyphase_analyze,
    polyphase_roundtrip_certificate,
    polyphase_synthesize as signal_polyphase_synthesize,
    refinement_children,
    residue_project,
)

# Readable aliases retained on the curated surface.  The verb-first names are
# canonical in ``komorebi_math.refinement``; these aliases make discovery by
# the phrase "polyphase refine" straightforward without duplicating logic.
polyphase_refine = refine_polyphase
polyphase_coarsen = coarsen_polyphase
lattice_polyphase_refine = refine_lattice_polyphase
lattice_polyphase_coarsen = coarsen_lattice_polyphase

__all__ = [
    "PORTABLE_SCHEMA",
    "PORTABLE_SCHEMA_VERSION",
    "STABLE_API_STABILITY_LEVEL",
    "STABLE_PUBLIC_NAMESPACES",
    "ApiCompatibilityReport",
    "ArithmeticPolyphase",
    "AssumptionError",
    "BackendUnavailableError",
    "Certificate",
    "ComputationResult",
    "ConditionalResult",
    "DimensionError",
    "Exactness",
    "ExactnessError",
    "KomorebiMathError",
    "LatticePolyphaseCoordinates",
    "LatticePolyphaseRefinement",
    "PacketCoordinates",
    "PacketRefinement",
    "PacketSystem",
    "PolyphaseCoordinateRecord",
    "PolyphaseCoordinates",
    "PolyphaseRefinement",
    "PolyphaseRefinementTower",
    "PolyphaseSystem",
    "PortableCodec",
    "PortableMigration",
    "PublicApiManifest",
    "PublicApiSymbol",
    "RefinementTower",
    "ResidueCoordinates",
    "ResourceLimitError",
    "ValidationError",
    "__version__",
    "arithmetic_mixed_radix_address",
    "arithmetic_mixed_radix_digits",
    "arithmetic_polyphase_analyze",
    "arithmetic_polyphase_synthesize",
    "check_stable_api",
    "coarsen_lattice_polyphase",
    "coarsen_polyphase",
    "common_refinement",
    "create_stable_api_manifest",
    "dumps_portable",
    "from_portable_data",
    "lattice_polyphase_analyze",
    "lattice_polyphase_coarsen",
    "lattice_polyphase_refine",
    "lattice_polyphase_synthesize",
    "load_portable",
    "load_stable_api_manifest",
    "loads_portable",
    "mahler_polyphase",
    "nested_residue_address",
    "nested_residue_analysis",
    "polyphase_coarsen",
    "polyphase_refine",
    "polyphase_refinement_certificate",
    "polyphase_roundtrip_certificate",
    "portable_codecs",
    "portable_digest",
    "portable_migrations",
    "refine_lattice_polyphase",
    "refine_polyphase",
    "refinement_children",
    "residue_analyze",
    "residue_project",
    "residue_synthesize",
    "save_portable",
    "signal_polyphase_analyze",
    "signal_polyphase_synthesize",
    "to_portable_data",
]
