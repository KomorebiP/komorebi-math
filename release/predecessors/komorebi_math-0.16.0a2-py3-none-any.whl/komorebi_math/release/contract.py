"""Machine-readable release contract for the Komorebi Math 1.0 path.

The broad research namespace remains additive during the alpha series.  This
module records the narrower set of artifacts and behaviors that must remain
coherent before a beta or release candidate can be cut.  It checks API
manifests, semantic fixtures, portable codecs, versioned aliases, CLI routes,
and the declared support policy as separate layers.
"""

from __future__ import annotations

import json
import platform
import sys
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from enum import StrEnum
from hashlib import sha256
from importlib import import_module
from pathlib import Path
from typing import Any

from .._version import __version__
from ..certificates import Certificate, Exactness
from ..cli.contracts import VERIFICATION_SUITE_NAMES
from ..compatibility import check_beta_api, check_public_api, check_stable_api
from ..exceptions import ValidationError
from ..persistence_contract import check_portable_codec_contract
from ..stable_semantics import run_stable_semantics_fixture
from ..support import load_support_matrix, runtime_environment

RELEASE_CONTRACT_SCHEMA = "komorebi-math.release-contract"
RELEASE_CONTRACT_SCHEMA_VERSION = 1
DEFAULT_RELEASE_CONTRACT = Path(__file__).resolve().parents[1] / "data" / "release_contract_0_16.json"


class ApiTier(StrEnum):
    """Compatibility tier assigned to one public surface."""

    STABLE = "stable"
    BETA = "beta"
    RESEARCH = "research"
    INTERNAL = "internal"


def _canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def _file_digest(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def _mapping(value: Any, name: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise ValidationError(f"{name} must be an object")
    return value


def _sequence(value: Any, name: str) -> Sequence[Any]:
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        raise ValidationError(f"{name} must be an array")
    return value


@dataclass(frozen=True, slots=True)
class ContractArtifact:
    """One immutable release artifact and its expected identity."""

    filename: str
    sha256: str
    count: int

    def __post_init__(self) -> None:
        if not self.filename.strip():
            raise ValidationError("release contract artifact filename must be nonempty")
        if len(self.sha256) != 64 or any(character not in "0123456789abcdef" for character in self.sha256):
            raise ValidationError("release contract artifact digest must be lowercase SHA-256")
        if int(self.count) < 0:
            raise ValidationError("release contract artifact count cannot be negative")

    def to_dict(self) -> dict[str, Any]:
        return {"filename": self.filename, "sha256": self.sha256, "count": self.count}

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ContractArtifact":
        if set(value) != {"filename", "sha256", "count"}:
            raise ValidationError("release contract artifact fields do not match the schema")
        return cls(str(value["filename"]), str(value["sha256"]), int(value["count"]))


@dataclass(frozen=True, slots=True)
class ReleaseContract:
    """Static contract that defines the Block 16 freeze candidate."""

    package_version: str
    release_line: str
    python_requires: str
    declared_python: tuple[str, ...]
    required_platforms: tuple[str, ...]
    stable_api: ContractArtifact
    beta_api: ContractArtifact
    research_api: ContractArtifact
    semantics: ContractArtifact
    persistence: ContractArtifact
    stable_aliases: tuple[str, ...]
    required_cli_suites: tuple[str, ...]
    schema: str = RELEASE_CONTRACT_SCHEMA
    schema_version: int = RELEASE_CONTRACT_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if self.schema != RELEASE_CONTRACT_SCHEMA:
            raise ValidationError("unknown release contract schema")
        if int(self.schema_version) != RELEASE_CONTRACT_SCHEMA_VERSION:
            raise ValidationError("unsupported release contract schema version")
        if not self.package_version.strip() or not self.release_line.strip() or not self.python_requires.strip():
            raise ValidationError("release contract identity fields must be nonempty")
        for name, values in (
            ("declared_python", self.declared_python),
            ("required_platforms", self.required_platforms),
            ("stable_aliases", self.stable_aliases),
            ("required_cli_suites", self.required_cli_suites),
        ):
            if not values or len(set(values)) != len(values) or any(not value.strip() for value in values):
                raise ValidationError(f"release contract {name} must be nonempty and unique")

    @property
    def digest(self) -> str:
        """Return the canonical digest of the contract itself."""

        return sha256(_canonical_json(self.to_dict()).encode("utf-8")).hexdigest()

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": self.schema,
            "schema_version": self.schema_version,
            "package_version": self.package_version,
            "release_line": self.release_line,
            "runtime": {
                "python_requires": self.python_requires,
                "declared_python": list(self.declared_python),
                "required_platforms": list(self.required_platforms),
            },
            "api": {
                ApiTier.STABLE.value: self.stable_api.to_dict(),
                ApiTier.BETA.value: self.beta_api.to_dict(),
                ApiTier.RESEARCH.value: self.research_api.to_dict(),
                "stable_aliases": list(self.stable_aliases),
            },
            "semantics": self.semantics.to_dict(),
            "persistence": self.persistence.to_dict(),
            "cli": {"required_verification_suites": list(self.required_cli_suites)},
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ReleaseContract":
        required = {
            "schema",
            "schema_version",
            "package_version",
            "release_line",
            "runtime",
            "api",
            "semantics",
            "persistence",
            "cli",
        }
        if set(value) != required:
            raise ValidationError("release contract fields do not match the schema")
        runtime = _mapping(value["runtime"], "release contract runtime")
        api = _mapping(value["api"], "release contract API")
        cli = _mapping(value["cli"], "release contract CLI")
        if set(runtime) != {"python_requires", "declared_python", "required_platforms"}:
            raise ValidationError("release contract runtime fields do not match the schema")
        if set(api) != {"stable", "beta", "research", "stable_aliases"}:
            raise ValidationError("release contract API fields do not match the schema")
        if set(cli) != {"required_verification_suites"}:
            raise ValidationError("release contract CLI fields do not match the schema")
        return cls(
            package_version=str(value["package_version"]),
            release_line=str(value["release_line"]),
            python_requires=str(runtime["python_requires"]),
            declared_python=tuple(str(item) for item in _sequence(runtime["declared_python"], "declared Python versions")),
            required_platforms=tuple(str(item) for item in _sequence(runtime["required_platforms"], "required platforms")),
            stable_api=ContractArtifact.from_dict(_mapping(api["stable"], "stable API artifact")),
            beta_api=ContractArtifact.from_dict(_mapping(api["beta"], "beta API artifact")),
            research_api=ContractArtifact.from_dict(_mapping(api["research"], "research API artifact")),
            semantics=ContractArtifact.from_dict(_mapping(value["semantics"], "semantic artifact")),
            persistence=ContractArtifact.from_dict(_mapping(value["persistence"], "persistence artifact")),
            stable_aliases=tuple(str(item) for item in _sequence(api["stable_aliases"], "stable aliases")),
            required_cli_suites=tuple(
                str(item)
                for item in _sequence(cli["required_verification_suites"], "required CLI suites")
            ),
            schema=str(value["schema"]),
            schema_version=int(value["schema_version"]),
        )


@dataclass(frozen=True, slots=True)
class QualificationCheck:
    """One named release-contract check."""

    name: str
    passed: bool
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "passed": self.passed, "detail": self.detail}


@dataclass(frozen=True, slots=True)
class ReleaseContractReport:
    """Result of checking a release tree against its frozen contract."""

    contract: ReleaseContract
    checks: tuple[QualificationCheck, ...]
    runtime: Mapping[str, Any]
    certificate: Certificate

    @property
    def passed(self) -> bool:
        return self.certificate.valid

    def to_dict(self) -> dict[str, Any]:
        return {
            "contract": self.contract.to_dict(),
            "contract_digest": self.contract.digest,
            "passed": self.passed,
            "checks": [check.to_dict() for check in self.checks],
            "runtime": dict(self.runtime),
            "certificate": self.certificate.to_dict(),
        }


def load_release_contract(path: str | Path | None = None) -> ReleaseContract:
    """Load and validate a committed release contract."""

    source = DEFAULT_RELEASE_CONTRACT if path is None else Path(path)
    try:
        value = json.loads(source.read_text(encoding="utf-8"))
    except OSError as exc:
        raise ValidationError(f"could not read release contract {source}") from exc
    except json.JSONDecodeError as exc:
        raise ValidationError("release contract is not valid JSON") from exc
    return ReleaseContract.from_dict(_mapping(value, "release contract"))


def _capture(name: str, function: Any) -> QualificationCheck:
    try:
        function()
        return QualificationCheck(name, True)
    except Exception as exc:
        return QualificationCheck(name, False, f"{type(exc).__name__}: {exc}")


def _artifact_check(artifact: ContractArtifact, key: str) -> None:
    base = Path(__file__).resolve().parents[1] / "data"
    path = base / artifact.filename
    if not path.is_file():
        raise ValidationError(f"release artifact is missing: {artifact.filename}")
    if _file_digest(path) != artifact.sha256:
        raise ValidationError(f"release artifact digest changed: {artifact.filename}")
    payload = json.loads(path.read_text(encoding="utf-8"))
    values = payload.get(key)
    if not isinstance(values, list) or len(values) != artifact.count:
        raise ValidationError(
            f"release artifact count changed for {artifact.filename}: expected {artifact.count}"
        )


def check_release_contract(path: str | Path | None = None) -> ReleaseContractReport:
    """Check all finite layers needed before the 1.0 beta sequence."""

    contract = load_release_contract(path)
    checks: list[QualificationCheck] = []

    checks.append(
        QualificationCheck(
            "release version identity",
            __version__ == contract.package_version,
            f"observed {__version__}; expected {contract.package_version}",
        )
    )
    checks.append(_capture("stable API artifact identity", lambda: _artifact_check(contract.stable_api, "symbols")))
    checks.append(_capture("beta API artifact identity", lambda: _artifact_check(contract.beta_api, "symbols")))
    checks.append(_capture("research API artifact identity", lambda: _artifact_check(contract.research_api, "symbols")))
    checks.append(_capture("semantic fixture identity", lambda: _artifact_check(contract.semantics, "cases")))
    checks.append(_capture("portable codec contract identity", lambda: _artifact_check(contract.persistence, "entries")))

    checks.append(_capture("stable API structural compatibility", lambda: check_stable_api().certificate.require()))
    checks.append(_capture("beta API structural compatibility", lambda: check_beta_api().certificate.require()))
    checks.append(
        _capture(
            "research API snapshot compatibility",
            lambda: check_public_api(strict_signatures=True).certificate.require(),
        )
    )
    checks.append(_capture("stable semantic compatibility", lambda: run_stable_semantics_fixture().certificate.require()))
    checks.append(_capture("portable codec compatibility", lambda: check_portable_codec_contract().certificate.require()))

    def aliases() -> None:
        modules = [import_module(name) for name in contract.stable_aliases]
        reference = modules[0]
        for module in modules[1:]:
            if tuple(reference.__all__) != tuple(module.__all__):
                raise ValidationError(f"stable alias {module.__name__} has a different export list")
            for name in reference.__all__:
                if getattr(reference, name) is not getattr(module, name):
                    raise ValidationError(f"stable alias object identity changed for {name}")

    checks.append(_capture("versioned stable aliases", aliases))

    def cli_contract() -> None:
        missing = tuple(name for name in contract.required_cli_suites if name not in VERIFICATION_SUITE_NAMES)
        if missing:
            raise ValidationError(f"required verification suites are missing: {missing}")

    checks.append(_capture("frozen CLI verification routes", cli_contract))

    def support_policy() -> None:
        matrix = load_support_matrix()
        if tuple(matrix.python.get("declared", ())) != contract.declared_python:
            raise ValidationError("support matrix Python versions differ from the release contract")
        if not matrix.validated_environments:
            raise ValidationError("support matrix has no executed environment evidence")

    checks.append(_capture("declared support policy", support_policy))

    passed = all(check.passed for check in checks)
    certificate = Certificate(
        valid=passed,
        exactness=Exactness.EXACT,
        residuals={"failed_checks": float(sum(not check.passed for check in checks))},
        assumptions_checked=tuple(check.name for check in checks if check.passed),
        assumptions_unchecked=(
            "declared platforms not represented by an executed validation record remain provisional",
            "hardware performance is not part of the semantic compatibility contract",
        ),
        diagnostics={
            "package_version": __version__,
            "python": platform.python_version(),
            "contract_digest": contract.digest,
            "required_platforms": contract.required_platforms,
        },
        theorem_id="KM-RELEASE-CONTRACT-016",
        message="Block 16 release contract passed" if passed else "Block 16 release contract failed",
    )
    return ReleaseContractReport(contract, tuple(checks), runtime_environment(), certificate)


def current_runtime_record() -> dict[str, Any]:
    """Return the current finite runtime record used by release reports."""

    return {
        "package_version": __version__,
        "python": platform.python_version(),
        "python_executable": sys.executable,
        "platform": platform.platform(),
        "environment": runtime_environment(),
    }


__all__ = [
    "ApiTier",
    "ContractArtifact",
    "DEFAULT_RELEASE_CONTRACT",
    "QualificationCheck",
    "RELEASE_CONTRACT_SCHEMA",
    "RELEASE_CONTRACT_SCHEMA_VERSION",
    "ReleaseContract",
    "ReleaseContractReport",
    "check_release_contract",
    "current_runtime_record",
    "load_release_contract",
]
