# Release Process

## Alpha freeze candidate

`1.0.0b1` may still receive corrections to the candidate surface. Every correction must regenerate all API manifests, the codec inventory when needed, and release hashes.

## Beta freeze

`1.0.0b1` freezes the stable namespace, semantic fixture schema, and persistence compatibility policy. After beta, stable signature changes require explicit review and generally a deprecation path.

## Release candidate

A release candidate must be built from a clean tag and pass:

- complete source tests
- focused Block 16 tests
- static import and compilation audit
- strict stable API comparison
- stable semantic fixture
- portable codec migration contract
- installed-wheel verification outside the source directory
- source-distribution reconstruction and wheel rebuild
- the declared CPU platform matrix
- hardware-backed CUDA qualification on the recorded NVIDIA environment
- strict documentation build
- archive integrity and SHA-256 verification

## Final release

`1.0.0` should differ from the successful release candidate only in approved version and release metadata. Any code change after `rc1` produces `rc2` or later.

## Local commands

```powershell
.\Run_Block16_Source_Validation.ps1
.\Run_Block16_Batched_Validation.ps1
.\Build_Block16_Distributions.ps1
.\Install_And_Verify_Block16.ps1 -Recreate
.\Run_GPU_Validation.ps1
```
