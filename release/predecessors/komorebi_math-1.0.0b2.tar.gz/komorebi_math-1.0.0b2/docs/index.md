# Komorebi Math documentation

Version `1.0.0b1` provides fourteen mathematical blocks and two stabilization blocks with explicit exact, numerical, conditional, API, semantic, persistence, and release certificates.

## Start here

* [Block 16 release and freeze candidate](BLOCK_16_RELEASE.md)
* [Stable API contract](STABLE_API.md)
* [Release qualification](RELEASE_QUALIFICATION.md)
* [Windows CUDA installation](GPU_INSTALLATION.md)
* [Migration to 1.0](MIGRATION_TO_1_0.md)
* [Companion C integration map](COMPANION_C_INTEGRATION.md)
* [Public API](PUBLIC_API.md)
* [Unified executable language](UNIFIED_LANGUAGE.md)
* [Implementation roadmap](IMPLEMENTATION_ROADMAP.md)
* [Normalized generating functions](NORMALIZED_GENERATING_FUNCTIONS.md)
* [Block 13 release](BLOCK_13_RELEASE.md)
* [Block 14 release](BLOCK_14_RELEASE.md)
* [General coordinate atlas](GENERAL_COORDINATE_ATLAS.md)
* [Companion coordinate examples](COMPANION_COORDINATE_CALCULUS.md)
* [Local Windows validation](LOCAL_VALIDATION.md)
* [Fourteenth major block report](FOURTEENTH_MAJOR_BLOCK_REPORT.md)
* [API compatibility contract for 0.14](API_COMPATIBILITY_0.14.md)
* [Thirteenth major block report](THIRTEENTH_MAJOR_BLOCK_REPORT.md)
* [API compatibility contract for 0.13](API_COMPATIBILITY_0.13.md)
* [Production signal processing](PRODUCTION_SIGNAL_PROCESSING.md)
* [Block 12 release](BLOCK_12_RELEASE.md)
* [Twelfth major block report](TWELFTH_MAJOR_BLOCK_REPORT.md)
* [API compatibility contract for 0.12](API_COMPATIBILITY_0.12.md)
* [Block 11 release](BLOCK_11_RELEASE.md)
* [Eleventh major block report](ELEVENTH_MAJOR_BLOCK_REPORT.md)
* [Resumable packet-jet streams](STREAMING_PACKET_JETS.md)
* [Behavioral fixtures and finite profiling](BEHAVIORAL_GOLDEN_AND_PROFILING.md)
* [API compatibility contract for 0.11](API_COMPATIBILITY_0.11.md)
* [Block 10 release](BLOCK_10_RELEASE.md)
* [Scalable nonlinear execution](SCALABLE_NONLINEAR_EXECUTION.md)
* [Portable persistence schemas](PERSISTENCE_SCHEMAS.md)
* [API compatibility contract for 0.10](API_COMPATIBILITY_0.10.md)
* [Deprecation policy](DEPRECATION_POLICY.md)
* [Block 9 release](BLOCK_9_RELEASE.md)
* [Finite nonlinear packet calculus](NONLINEAR_CALCULUS.md)
* [API stability review](API_STABILITY_REVIEW.md)
* [Portable export and LaTeX](EXPORT_AND_LATEX.md)

## Validation

The source distribution includes the unit suite, installed verification suites, and independent deep-audit scripts. The Block 16 release retains all earlier layers and adds strict stable signatures, committed mathematical semantics, portable codec migration checks, general analysis--synthesis reconstruction, release qualification, and optional hardware-backed CUDA validation. Exact Block 16 counts and artifact identities are recorded in the release qualification and distribution ledgers shipped with the handoff. Platform or device paths are reported as passed only when they were actually executed.
