"""Finite matrix transport, gauges, and holonomy certificates."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping

from ..backends import LinearAlgebraBackend, get_backend
from ..certificates import Certificate, Exactness
from ..exceptions import DimensionError, ValidationError
from ..provenance import ClaimStatus, ProvenanceRecord, documented


@dataclass(frozen=True, slots=True)
class TransportEdge:
    """An invertible transport from ``source`` to ``target``."""

    source: str
    target: str
    matrix: Any
    name: str = ""

    def reversed_name(self) -> str:
        return self.name or f"{self.target}->{self.source}"


@dataclass(frozen=True, slots=True)
class FundamentalHolonomy:
    """One non tree edge and its based cycle holonomy."""

    edge_index: int
    source: str
    target: str
    matrix: Any


@dataclass(frozen=True, slots=True)
class IntertwiningResult:
    """Vertex intertwiners propagated along a spanning tree."""

    intertwiners: Mapping[str, Any]
    edge_residuals: Mapping[str, float]
    cycle_residuals: Mapping[str, float]
    certificate: Certificate


@documented(
    ProvenanceRecord(
        identifier="PSC-III-D38",
        title="Finite matrix transport system",
        status=ClaimStatus.DEFINITION,
        source="Paper III",
        assumptions=("connected finite graph", "invertible edge transports", "one model fiber dimension"),
        verification_suite="nonlinear.holonomy",
    )
)
class TransportGraph:
    """A connected finite graph with invertible matrix transports."""

    def __init__(
        self,
        vertices: Iterable[str],
        edges: Iterable[TransportEdge],
        *,
        backend: str | LinearAlgebraBackend | None = None,
        tolerance: float = 1e-10,
    ) -> None:
        self.vertices = tuple(dict.fromkeys(str(vertex) for vertex in vertices))
        if not self.vertices:
            raise ValueError("transport graph requires at least one vertex")
        self.vertex_set = frozenset(self.vertices)
        self.backend = get_backend(backend)
        self.tolerance = float(tolerance)
        self.edges = tuple(edges)
        if not self.edges and len(self.vertices) > 1:
            raise ValidationError("a multivertex transport graph needs edges")
        dimensions: set[int] = set()
        for edge in self.edges:
            if edge.source not in self.vertex_set or edge.target not in self.vertex_set:
                raise ValidationError("transport edge references an unknown vertex")
            matrix = self.backend.as_matrix(edge.matrix)
            rows, columns = self.backend.shape(matrix)
            if rows != columns:
                raise DimensionError("transport matrices must be square")
            dimensions.add(rows)
            self.backend.inverse(matrix)
        if len(dimensions) > 1:
            raise DimensionError("all transport matrices must use one model fiber dimension")
        self.dimension = next(iter(dimensions), 1)
        if len(self._reachable(self.vertices[0])) != len(self.vertices):
            raise ValidationError("transport graph must be connected")

    def _oriented_adjacency(self) -> dict[str, list[tuple[str, int, bool]]]:
        adjacency = {vertex: [] for vertex in self.vertices}
        for index, edge in enumerate(self.edges):
            adjacency[edge.source].append((edge.target, index, False))
            adjacency[edge.target].append((edge.source, index, True))
        return adjacency

    def _reachable(self, root: str) -> frozenset[str]:
        adjacency = self._oriented_adjacency()
        seen = {root}
        stack = [root]
        while stack:
            vertex = stack.pop()
            for neighbor, _, _ in adjacency[vertex]:
                if neighbor not in seen:
                    seen.add(neighbor)
                    stack.append(neighbor)
        return frozenset(seen)

    def edge_label(self, edge_index: int) -> str:
        """Return a stable unique label for one transport edge."""

        edge = self.edges[edge_index]
        return f"{edge.name or 'edge'}[{edge_index}]"

    def oriented_matrix(self, edge_index: int, *, reverse: bool = False) -> Any:
        matrix = self.backend.as_matrix(self.edges[edge_index].matrix)
        return self.backend.inverse(matrix) if reverse else matrix

    def spanning_tree(self, root: str | None = None) -> tuple[dict[str, tuple[str, int, bool] | None], tuple[int, ...]]:
        root_vertex = self.vertices[0] if root is None else root
        if root_vertex not in self.vertex_set:
            raise KeyError("unknown root vertex")
        adjacency = self._oriented_adjacency()
        parent: dict[str, tuple[str, int, bool] | None] = {root_vertex: None}
        tree_edges: list[int] = []
        queue = [root_vertex]
        while queue:
            vertex = queue.pop(0)
            for neighbor, edge_index, reverse in adjacency[vertex]:
                if neighbor in parent:
                    continue
                parent[neighbor] = (vertex, edge_index, reverse)
                tree_edges.append(edge_index)
                queue.append(neighbor)
        return parent, tuple(tree_edges)

    def tree_transports(self, root: str | None = None) -> dict[str, Any]:
        """Return transports from the root fiber to every vertex along one spanning tree."""

        root_vertex = self.vertices[0] if root is None else root
        parent, _ = self.spanning_tree(root_vertex)
        transports: dict[str, Any] = {root_vertex: self.backend.eye(self.dimension)}
        unresolved = set(self.vertices) - {root_vertex}
        while unresolved:
            progress = False
            for vertex in tuple(unresolved):
                relation = parent[vertex]
                if relation is None:
                    raise ArithmeticError("nonroot vertex has no tree parent")
                parent_vertex, edge_index, reverse = relation
                if parent_vertex not in transports:
                    continue
                step = self.oriented_matrix(edge_index, reverse=reverse)
                transports[vertex] = self.backend.matmul(step, transports[parent_vertex])
                unresolved.remove(vertex)
                progress = True
            if not progress:
                raise ArithmeticError("failed to propagate spanning tree transports")
        return transports

    @documented(
        ProvenanceRecord(
            identifier="PSC-III-T39",
            title="Spanning tree normalization",
            status=ClaimStatus.PROVED,
            source="Paper III",
            assumptions=("connected transport graph",),
            verification_suite="nonlinear.holonomy",
        )
    )
    def tree_gauge(self, root: str | None = None) -> dict[str, Any]:
        return {vertex: self.backend.inverse(matrix) for vertex, matrix in self.tree_transports(root).items()}

    def gauge_transform(self, gauges: Mapping[str, Any]) -> "TransportGraph":
        if set(gauges) != set(self.vertices):
            raise ValidationError("a gauge matrix is required at every vertex")
        gauge_matrices = {
            vertex: self.backend.as_matrix(gauges[vertex])
            for vertex in self.vertices
        }
        for vertex, matrix in gauge_matrices.items():
            if self.backend.shape(matrix) != (self.dimension, self.dimension):
                raise DimensionError(f"gauge at vertex {vertex!r} has the wrong fiber dimension")
            self.backend.inverse(matrix)
        transformed: list[TransportEdge] = []
        for edge in self.edges:
            left = gauge_matrices[edge.target]
            right_inverse = self.backend.inverse(gauge_matrices[edge.source])
            matrix = self.backend.matmul(left, self.backend.matmul(self.backend.as_matrix(edge.matrix), right_inverse))
            transformed.append(TransportEdge(edge.source, edge.target, matrix, edge.name))
        return TransportGraph(self.vertices, transformed, backend=self.backend, tolerance=self.tolerance)

    @documented(
        ProvenanceRecord(
            identifier="PSC-III-T40",
            title="Fundamental cycle holonomy criterion",
            status=ClaimStatus.PROVED,
            source="Paper III",
            assumptions=("connected finite graph",),
            verification_suite="nonlinear.holonomy",
        )
    )
    def fundamental_holonomies(self, root: str | None = None) -> tuple[FundamentalHolonomy, ...]:
        root_vertex = self.vertices[0] if root is None else root
        transports = self.tree_transports(root_vertex)
        _, tree_edges = self.spanning_tree(root_vertex)
        tree_set = set(tree_edges)
        output: list[FundamentalHolonomy] = []
        for index, edge in enumerate(self.edges):
            if index in tree_set:
                continue
            holonomy = self.backend.matmul(
                self.backend.inverse(transports[edge.target]),
                self.backend.matmul(self.backend.as_matrix(edge.matrix), transports[edge.source]),
            )
            output.append(FundamentalHolonomy(index, edge.source, edge.target, holonomy))
        return tuple(output)

    def gluing_certificate(self, root: str | None = None) -> Certificate:
        identity = self.backend.eye(self.dimension)
        residuals = {
            self.edge_label(item.edge_index): self.backend.norm(
                self.backend.subtract(item.matrix, identity)
            )
            for item in self.fundamental_holonomies(root)
        }
        valid = all(
            residual == 0.0 if self.backend.exact else residual <= self.tolerance
            for residual in residuals.values()
        )
        return Certificate(
            valid=bool(valid),
            exactness=Exactness.EXACT if self.backend.exact else Exactness.NUMERICAL,
            residuals=residuals,
            tolerance=None if self.backend.exact else self.tolerance,
            assumptions_checked=("spanning tree normalization", "fundamental cycle basis"),
            diagnostics={"betti_number": len(self.edges) - len(self.vertices) + 1},
            theorem_id="PSC-III-T40",
            message="all fundamental holonomies are trivial" if valid else "one or more fundamental holonomies are nontrivial",
        )

    @documented(
        ProvenanceRecord(
            identifier="PSC-III-T41",
            title="Fundamental holonomy intertwining criterion",
            status=ClaimStatus.PROVED,
            source="Paper III",
            assumptions=("two transport systems on the same graph", "root intertwiner"),
            verification_suite="nonlinear.holonomy",
        )
    )
    def intertwine(
        self,
        other: "TransportGraph",
        root_intertwiner: Any,
        *,
        root: str | None = None,
    ) -> IntertwiningResult:
        if self.vertices != other.vertices or len(self.edges) != len(other.edges):
            raise ValidationError("transport systems must use the same ordered graph")
        if self.backend.name != other.backend.name or self.dimension != other.dimension:
            raise ValidationError("transport systems must use one backend and fiber dimension")
        for left, right in zip(self.edges, other.edges, strict=True):
            if (left.source, left.target) != (right.source, right.target):
                raise ValidationError("transport edge orientations do not agree")
        root_vertex = self.vertices[0] if root is None else root
        source_paths = self.tree_transports(root_vertex)
        target_paths = other.tree_transports(root_vertex)
        root_map = self.backend.as_matrix(root_intertwiner)
        if self.backend.shape(root_map) != (self.dimension, self.dimension):
            raise DimensionError("root intertwiner has the wrong fiber dimension")
        intertwiners = {
            vertex: self.backend.matmul(
                target_paths[vertex],
                self.backend.matmul(root_map, self.backend.inverse(source_paths[vertex])),
            )
            for vertex in self.vertices
        }
        edge_residuals: dict[str, float] = {}
        for index, (source_edge, target_edge) in enumerate(zip(self.edges, other.edges, strict=True)):
            residual = self.backend.subtract(
                self.backend.matmul(intertwiners[source_edge.target], self.backend.as_matrix(source_edge.matrix)),
                self.backend.matmul(self.backend.as_matrix(target_edge.matrix), intertwiners[source_edge.source]),
            )
            edge_residuals[self.edge_label(index)] = self.backend.norm(residual)

        source_holonomy = self.fundamental_holonomies(root_vertex)
        target_holonomy = other.fundamental_holonomies(root_vertex)
        cycle_residuals: dict[str, float] = {}
        for source_item, target_item in zip(source_holonomy, target_holonomy, strict=True):
            residual = self.backend.subtract(
                self.backend.matmul(root_map, source_item.matrix),
                self.backend.matmul(target_item.matrix, root_map),
            )
            cycle_residuals[self.edge_label(source_item.edge_index)] = self.backend.norm(residual)
        edge_valid = all(
            residual == 0.0 if self.backend.exact else residual <= self.tolerance
            for residual in edge_residuals.values()
        )
        cycle_valid = all(
            residual == 0.0 if self.backend.exact else residual <= self.tolerance
            for residual in cycle_residuals.values()
        )
        valid = edge_valid and cycle_valid
        certificate = Certificate(
            valid=bool(valid),
            exactness=Exactness.EXACT if self.backend.exact else Exactness.NUMERICAL,
            residuals={
                **{f"edge:{name}": value for name, value in edge_residuals.items()},
                **{f"cycle:{name}": value for name, value in cycle_residuals.items()},
            },
            tolerance=None if self.backend.exact else self.tolerance,
            assumptions_checked=("common graph", "tree propagated vertex intertwiners", "fundamental cycle tests"),
            diagnostics={"root": root_vertex, "cycles": len(cycle_residuals)},
            theorem_id="PSC-III-T41",
            message="global packet transports intertwine" if valid else "transport intertwining obstruction is nonzero",
        )
        return IntertwiningResult(intertwiners, edge_residuals, cycle_residuals, certificate)


__all__ = [
    "FundamentalHolonomy",
    "IntertwiningResult",
    "TransportEdge",
    "TransportGraph",
]
