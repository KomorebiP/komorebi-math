"""Finite quantum error correction through Knill Laflamme compression."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

import numpy as np

from ..certificates import Certificate, Exactness
from ..exceptions import DimensionError, ValidationError
from ..provenance import ClaimStatus, ProvenanceRecord, documented
from ._validation import as_square_matrix, density_matrix, require_projector
from .channels import QuantumChannel


@dataclass(frozen=True, slots=True)
class KnillLaflammeReport:
    """Compressed error matrix and residuals for one finite code."""

    coefficient_matrix: np.ndarray
    residual_matrix: np.ndarray
    maximum_residual: float
    certificate: Certificate


@documented(
    ProvenanceRecord(
        identifier="PSC-VII-T42",
        title="Knill Laflamme compression criterion",
        status=ClaimStatus.CLASSICAL,
        source="Paper VII",
        assumptions=("finite orthogonal code projector", "finite error family"),
        verification_suite="quantum.error_correction",
    )
)
class QuantumCode:
    """A finite code projector with a declared family of error operators."""

    def __init__(self, projector: Any, errors: Iterable[Any], *, tolerance: float = 1e-10) -> None:
        p = require_projector(projector, tolerance=tolerance, name="code projector")
        operators = tuple(as_square_matrix(value, name="error operator") for value in errors)
        if not operators:
            raise ValidationError("a quantum code requires at least one error operator")
        if any(operator.shape != p.shape for operator in operators):
            raise DimensionError("every error must act on the code Hilbert space")
        rank = int(round(float(np.trace(p).real)))
        if rank < 1:
            raise ValidationError("code projector must have positive rank")
        self.projector = p
        self.errors = operators
        self.dimension = p.shape[0]
        self.code_dimension = rank
        self.tolerance = float(tolerance)

    def knill_laflamme_report(self) -> KnillLaflammeReport:
        """Return the scalar compression matrix and packet obstruction residuals."""

        count = len(self.errors)
        coefficients = np.zeros((count, count), dtype=complex)
        residuals = np.zeros((count, count), dtype=float)
        for left, error_left in enumerate(self.errors):
            for right, error_right in enumerate(self.errors):
                compressed = self.projector @ error_left.conj().T @ error_right @ self.projector
                scalar = np.trace(compressed) / self.code_dimension
                coefficients[left, right] = scalar
                residuals[left, right] = np.linalg.norm(compressed - scalar * self.projector, ord=2)
        maximum = float(np.max(residuals))
        scale = max(1.0, float(np.linalg.norm(coefficients, ord=2)))
        return KnillLaflammeReport(
            coefficients,
            residuals,
            maximum,
            Certificate(
                valid=maximum <= self.tolerance * scale,
                exactness=Exactness.NUMERICAL,
                residuals={"compression_obstruction": maximum},
                tolerance=self.tolerance * scale,
                assumptions_checked=("orthogonal code projector", "finite error family"),
                theorem_id="PSC-VII-T42",
                message="error products compress to scalars on the code",
            ),
        )

    def recovery_channel(self) -> QuantumChannel:
        """Construct a trace preserving recovery channel when the criterion holds."""

        report = self.knill_laflamme_report()
        report.certificate.require()
        hermitian = (report.coefficient_matrix + report.coefficient_matrix.conj().T) / 2
        eigenvalues, eigenvectors = np.linalg.eigh(hermitian)
        active = [index for index, value in enumerate(eigenvalues) if value > self.tolerance]
        recovery_kraus: list[np.ndarray] = []
        syndrome_projector = np.zeros_like(self.projector)
        for index in active:
            coefficients = eigenvectors[:, index]
            transformed = sum(self.errors[error] * coefficients[error] for error in range(len(self.errors)))
            isometry = transformed @ self.projector / np.sqrt(eigenvalues[index])
            syndrome = isometry @ isometry.conj().T
            syndrome_projector += syndrome
            recovery_kraus.append(isometry.conj().T)
        complement = (np.eye(self.dimension, dtype=complex) - syndrome_projector)
        complement = (complement + complement.conj().T) / 2
        values, vectors = np.linalg.eigh(complement)
        code_values, code_vectors = np.linalg.eigh(self.projector)
        code_vector = code_vectors[:, int(np.argmax(code_values))]
        for value, vector in zip(values, vectors.T, strict=True):
            if value > self.tolerance:
                recovery_kraus.append(np.sqrt(value) * np.outer(code_vector, vector.conj()))
        return QuantumChannel(recovery_kraus, tolerance=max(self.tolerance, 1e-9))

    def recovered_channel_certificate(self) -> Certificate:
        """Check exact recovery of the equal weight error channel on code matrix units."""

        recovery = self.recovery_channel()
        noise = QuantumChannel(
            tuple(error / np.sqrt(len(self.errors)) for error in self.errors),
            tolerance=max(self.tolerance, 1e-9),
        )
        noise_certificate = noise.certificate()
        if not noise_certificate.valid:
            trace_residual = float(noise_certificate.residuals.get("trace_preservation", float("inf")))
            return Certificate(
                valid=False,
                exactness=Exactness.NUMERICAL,
                residuals={"noise_trace_preservation": trace_residual},
                tolerance=noise_certificate.tolerance,
                assumptions_checked=("Knill Laflamme compression",),
                assumptions_unchecked=("equal weight error family is trace preserving",),
                theorem_id="PSC-VII-T44",
                message="the declared equal weight error family does not define a quantum channel",
            )
        combined = recovery.compose(noise)
        code_values, code_vectors = np.linalg.eigh(self.projector)
        basis = code_vectors[:, code_values > 0.5]
        residual = 0.0
        for row in range(self.code_dimension):
            for column in range(self.code_dimension):
                unit = np.outer(basis[:, row], basis[:, column].conj())
                residual = max(residual, float(np.linalg.norm(combined.apply(unit) - unit, ord=2)))
        return Certificate(
            valid=residual <= max(self.tolerance * 100, 1e-8),
            exactness=Exactness.NUMERICAL,
            residuals={"recovered_code_matrix_units": residual},
            tolerance=max(self.tolerance * 100, 1e-8),
            assumptions_checked=("Knill Laflamme compression", "equal weight error channel"),
            theorem_id="PSC-VII-T44",
            message="constructed recovery restores every code matrix unit",
        )

    def encode_density(self, logical_state: Any) -> np.ndarray:
        """Embed a logical density matrix into the code subspace."""

        logical = density_matrix(logical_state, tolerance=self.tolerance)
        if logical.shape != (self.code_dimension, self.code_dimension):
            raise DimensionError("logical state dimension does not match the code rank")
        values, vectors = np.linalg.eigh(self.projector)
        basis = vectors[:, values > 0.5]
        return basis @ logical @ basis.conj().T


__all__ = ["KnillLaflammeReport", "QuantumCode"]
