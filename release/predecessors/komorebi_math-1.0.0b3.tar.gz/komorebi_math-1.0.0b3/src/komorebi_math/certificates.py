"""Typed certificates and result wrappers.

The package uses these classes to keep exact mathematics, numerical checks,
conditional constructions, heuristics, and planned features visibly distinct.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from enum import StrEnum
from typing import Any, Generic, TypeVar

from .exceptions import ValidationError

T = TypeVar("T")


class Exactness(StrEnum):
    EXACT = "exact"
    NUMERICAL = "numerical"
    CONDITIONAL = "conditional"
    HEURISTIC = "heuristic"
    PLANNED = "planned"


@dataclass(frozen=True, slots=True)
class Certificate:
    """Machine readable validation record."""

    valid: bool
    exactness: Exactness
    residuals: dict[str, float] = field(default_factory=dict)
    tolerance: float | None = None
    assumptions_checked: tuple[str, ...] = ()
    assumptions_unchecked: tuple[str, ...] = ()
    diagnostics: dict[str, Any] = field(default_factory=dict)
    theorem_id: str | None = None
    message: str = ""

    def require(self) -> "Certificate":
        """Return the certificate when valid, otherwise raise ValidationError."""
        if not self.valid:
            detail = self.message or "certificate validation failed"
            raise ValidationError(detail)
        return self

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["exactness"] = self.exactness.value
        return data

    def to_json(self, *, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent, sort_keys=True, default=str)


@dataclass(frozen=True, slots=True)
class ComputationResult(Generic[T]):
    """A value paired with its execution certificate."""

    value: T
    certificate: Certificate

    @property
    def valid(self) -> bool:
        return self.certificate.valid

    @property
    def exact(self) -> bool:
        return self.certificate.exactness is Exactness.EXACT

    def require(self) -> T:
        self.certificate.require()
        return self.value


@dataclass(frozen=True, slots=True)
class ConditionalResult(Generic[T]):
    """A value whose conclusion depends on explicit unchecked assumptions."""

    value: T
    certificate: Certificate

    def __post_init__(self) -> None:
        if self.certificate.exactness is not Exactness.CONDITIONAL:
            raise ValueError("ConditionalResult requires a conditional certificate")
