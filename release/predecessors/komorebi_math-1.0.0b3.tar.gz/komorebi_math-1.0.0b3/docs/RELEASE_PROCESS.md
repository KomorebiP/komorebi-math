# Release process

## Current beta checkpoint

`1.0.0b1` froze the 131-symbol stable namespace, stable semantic fixtures, and portable persistence contract. Blocks 18 and 19 were added only to the research tier in `1.0.0b2` and `1.0.0b3`; they do not silently expand the frozen stable or beta namespaces.

Every beta correction must regenerate the current API manifests and release evidence while comparing against retained immutable predecessor contracts. Stable signature changes require explicit review and normally a deprecation path.

## Block 19 qualification gate

A Block 19 distribution is eligible for handoff only after all of the following pass from the frozen source:

* 12/12 installed integration checks
* 24/24 aggregate Block 19 checks
* 6/6 frozen stable checks
* 174/174 cumulative Block 15 checks
* 16/16 independent mathematical checks
* the complete committed adversarial suite
* the exact worked result `106/5`
* additive research API comparison with no stable or beta drift
* complete wheel `RECORD`, safe paths, and byte equality with the frozen package source
* clean sdist extraction, wheel rebuild, normalized payload comparison, and isolated installation of both wheels
* a clean single-root source handoff archive and SHA-256 manifest

The rigorous composite-Simpson path is restricted to a provenance-matched `ExactPolynomial` on the same exact rational interval. A generic floating callable cannot receive a rigorous result unless a future interval or ball backend encloses evaluation, conversion, summation, and truncation errors.

## Release candidate

A release candidate must additionally be built from a clean tag and pass the declared CPU platform matrix, hardware-backed CUDA qualification on the recorded NVIDIA environment, a strict documentation build, and archive-integrity verification. Historical Windows or CUDA evidence is not recast as a current Block 19 result.

## Final release

`1.0.0` should differ from the successful release candidate only in approved version and release metadata. Any code change after `rc1` produces `rc2` or later.

## Local Block 19 commands

POSIX:

```console
./run_block19_source_validation.sh
./build_block19_distributions.sh
./install_and_verify_block19.sh
```

PowerShell:

```powershell
.\Run_Block19_Source_Validation.ps1
.\Build_Block19_Distributions.ps1
.\Install_And_Verify_Block19.ps1 -Recreate
```
