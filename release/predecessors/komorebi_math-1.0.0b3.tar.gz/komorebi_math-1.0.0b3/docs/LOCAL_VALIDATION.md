# Local Windows validation

Block 16 ships separate source, installed-wheel, distribution, and CUDA gates. The default source gate runs every test module in a fresh child interpreter. This avoids false coupling between native runtimes and unrelated test modules while preserving every assertion.

## Complete source qualification

```powershell
conda activate komorebi-full
Set-Location "$HOME\Downloads\Komorebi_Math_Complete_Handoff_0.16.0a2"
.\Run_Block16_Source_Validation.ps1 -Python "$env:CONDA_PREFIX\python.exe"
```

The default run writes `release\BLOCK16_ISOLATED_SOURCE_VALIDATION.json`. The explicit module-isolated entry point is also available:

```powershell
.\Run_Block16_Batched_Validation.ps1 -Python "$env:CONDA_PREFIX\python.exe"
```

A single-process diagnostic run is explicit:

```powershell
.\Run_Block16_Source_Validation.ps1 -Python "$env:CONDA_PREFIX\python.exe" -Monolithic
```

## Installed-wheel qualification

Build the distributions, then install and verify the wheel outside the source tree:

```powershell
.\Build_Block16_Distributions.ps1 -Python "$env:CONDA_PREFIX\python.exe"
.\Install_And_Verify_Block16.ps1 -Python "$env:CONDA_PREFIX\python.exe" -Recreate
```

The installed gate checks the package version, strict stable manifest, semantic fixture, persistence contract, release contract, complete installed verification graph, and dependency consistency.

## CUDA qualification

Run the hardware gate only in an environment containing a working CUDA PyTorch build and exactly one compatible CuPy distribution:

```powershell
.\Run_GPU_Validation.ps1 -Python "$env:CONDA_PREFIX\python.exe"
```

The PyTorch and CuPy computations execute in separate child interpreters. A native import failure, timeout, or abnormal process exit becomes a failed hardware record instead of terminating the parent release process.

## Direct stable-contract commands

```powershell
python -m komorebi_math api check --stable
python -m komorebi_math release contract
python -m komorebi_math release environment
python -m komorebi_math verify stable
python -m komorebi_math verify release
python -m komorebi_math verify block16
python -m komorebi_math release qualify --output .\release\BLOCK16_LOCAL_QUALIFICATION.json --force
```

The base wheel requires NumPy only. JAX, PyTorch, CuPy, SymPy, SciPy, and LaTeX remain optional and are qualified separately when installed.
