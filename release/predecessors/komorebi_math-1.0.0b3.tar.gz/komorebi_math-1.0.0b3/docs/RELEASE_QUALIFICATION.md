# Release Qualification

Block 16 separates source correctness, installed-wheel correctness, portable persistence, API compatibility, and hardware qualification.

## Source gate

```powershell
.\Run_Block16_Source_Validation.ps1 -Python "$env:CONDA_PREFIX\python.exe"
```

The focused gate is:

```powershell
.\Run_Block16_Source_Validation.ps1 -Python "$env:CONDA_PREFIX\python.exe" -Focused
```

## Installed wheel gate

```powershell
.\Install_And_Verify_Block16.ps1 -Recreate -OnlineDependencies
```

This creates a new environment, installs the wheel from `release/dist`, verifies that imports resolve outside the source tree, runs the stable and cumulative installed verifiers, executes release qualification, and runs `pip check`.

## Machine-readable qualification

```powershell
komorebi release qualify --output .\release\qualification.json --force
```

The record includes runtime versions, isolated optional-backend availability, each finite qualification check, and the aggregate certificate.

## CUDA gate

```powershell
.\Run_GPU_Validation.ps1 -Python "$env:CONDA_PREFIX\python.exe"
```

A missing GPU does not invalidate the base wheel. It invalidates only a release claim that explicitly requires CUDA qualification.
