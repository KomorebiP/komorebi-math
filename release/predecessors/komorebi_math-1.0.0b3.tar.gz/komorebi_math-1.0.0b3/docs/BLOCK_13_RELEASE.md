# Block 13 release

Version `0.13.0a1` promotes normalized generating functions and arithmetic compilers into the production wheel while retaining every earlier execution block.

## New production namespace

The complete API lives under:

```python
import komorebi_math.generating
```

The namespace contains 181 public exports across exact bases, finite series, custom sources, masks, congruences, Cartier operators, prime power arithmetic, Gaussian binomials, cyclotomic collapse, persistence, and signal adapters.

## Main capabilities

Block 13 adds:

* explicit exact coefficient domains
* finite normalized series and certified basis transfer
* declarative recurrence, rational, hypergeometric, algebraic, Euler-product, composition, and Bell sources
* finite closed-form recognition procedures with explicit search bounds
* local Mahler-mask product and inversion
* analytic mask realization with a conservative finite tail bound
* finite-mask and ordinary-product carry compilers
* rational-mask Cartier linear representations and minimized automata
* Bell digit-sum reductions and residue automata
* Kummer layer distributions and exact prime-power support
* exact binomial and normalized-kernel residues modulo `p**r`
* all-prime Gaussian `q`-Kummer valuations
* polynomial, Euler, and cyclotomic coboundary tests
* trusted portable records and a finite FIR bridge
* command-line mask, Cartier, kernel, and Bell calculations

## Commands

```powershell
python -m pip install .\komorebi_math-0.13.0a1-py3-none-any.whl
komorebi verify generating
komorebi verify block13
komorebi generating mask --mask "1,1,1" --radix 2 --count 20
komorebi generating cartier --numerator "1,1" --denominator "1,-1" --prime 5 --count 20
komorebi generating kernel --index 100 --subindex 37 --prime 3 --exponent 5 --power 2
komorebi generating bell --index 137 --prime 5 --power 9
komorebi api check --strict-signatures
python .\examples\custom_generating_functions.py
.\examples\Test-KomorebiBlock13.ps1
```

## Correctness boundary

Exact finite algebra, congruence, carry, Cartier, and prime-power statements are separated from numerical analytic bounds and bounded recognition procedures. Formal identities do not imply analytic convergence without the stated hypotheses. A failed bounded relation search is not a nonexistence proof. SHA-256 persistence digests establish integrity, not authorship or authenticity.

## Source validation checkpoint

The complete source suite passes 841 of 841 tests. The Block 13 generating and CLI subset passes 193 of 193 tests. The installed verification graph passes 146 of 146 checks, including 14 generating-function checks. The independent arithmetic audit passes 383,336 of 383,336 comparisons. The committed research API contains 901 symbols and the strict beta API remains unchanged at 83 symbols.
