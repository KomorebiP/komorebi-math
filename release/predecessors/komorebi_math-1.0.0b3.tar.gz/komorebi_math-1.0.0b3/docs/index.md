# Komorebi Math documentation

Version `1.0.0b3` contains nineteen numbered finite execution and stabilization blocks with explicit exact, numerical, conditional, API, semantic, persistence, and release certificates. The 131-symbol stable namespace was frozen in `1.0.0b1`; the Block 18 and Block 19 additions in `1.0.0b2` and `1.0.0b3` remain research-only.

## Start here

* [Block 19 finite measure and integration release](BLOCK_19_RELEASE.md)
* [Finite measure integration](FINITE_MEASURE_INTEGRATION.md)
* [Block 19 worked example](BLOCK_19_WORKED_EXAMPLE.md)
* [Block 18 redundant-frame release](BLOCK_18_RELEASE.md)
* [Redundant-frame coefficient algebra](REDUNDANT_FRAME_ALGEBRA.md)
* [Block 17 public beta](BLOCK_17_RELEASE.md)
* [Stable API contract](STABLE_API.md)
* [Release qualification](RELEASE_QUALIFICATION.md)
* [Windows CUDA installation](GPU_INSTALLATION.md)
* [Migration to 1.0](MIGRATION_TO_1_0.md)
* [Companion C integration map](COMPANION_C_INTEGRATION.md)
* [Public API](PUBLIC_API.md)
* [Unified executable language](UNIFIED_LANGUAGE.md)
* [Implementation roadmap](IMPLEMENTATION_ROADMAP.md)
* [Normalized generating functions](NORMALIZED_GENERATING_FUNCTIONS.md)
* [Block 16 release and freeze candidate](BLOCK_16_RELEASE.md)
* [Block 15 release](BLOCK_15_RELEASE.md)
* [Block 14 release](BLOCK_14_RELEASE.md)
* [Block 13 release](BLOCK_13_RELEASE.md)
* [General coordinate atlas](GENERAL_COORDINATE_ATLAS.md)
* [Companion coordinate examples](COMPANION_COORDINATE_CALCULUS.md)
* [Local Windows validation](LOCAL_VALIDATION.md)
* [Production signal processing](PRODUCTION_SIGNAL_PROCESSING.md)
* [Block 12 release](BLOCK_12_RELEASE.md)
* [Resumable packet-jet streams](STREAMING_PACKET_JETS.md)
* [Behavioral fixtures and finite profiling](BEHAVIORAL_GOLDEN_AND_PROFILING.md)
* [Block 11 release](BLOCK_11_RELEASE.md)
* [Scalable nonlinear execution](SCALABLE_NONLINEAR_EXECUTION.md)
* [Portable persistence schemas](PERSISTENCE_SCHEMAS.md)
* [Block 10 release](BLOCK_10_RELEASE.md)
* [Deprecation policy](DEPRECATION_POLICY.md)
* [Block 9 release](BLOCK_9_RELEASE.md)
* [Finite nonlinear packet calculus](NONLINEAR_CALCULUS.md)
* [API stability review](API_STABILITY_REVIEW.md)
* [Portable export and LaTeX](EXPORT_AND_LATEX.md)

## Validation

The source distribution includes the focused installed suites and independent deep-audit scripts. Block 19 retains the frozen stable, semantic, and portable-codec contracts while adding 12 focused installed integration checks and a 24-check Block 19 aggregate. Its committed adversarial runner covers 47 cases, and its independent mathematical verifier covers 16 checks.

Rigorous Simpson certification is limited to a provenance-matched `ExactPolynomial` on the same exact rational interval, with exact rational evaluation, summation, and bound arithmetic. Arbitrary floating callables remain estimated or conditional. Platform and device paths are reported as passed only when they were actually executed.
