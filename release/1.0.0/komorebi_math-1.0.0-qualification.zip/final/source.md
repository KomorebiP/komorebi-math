# Release Verification

Status: **PASSED**

Package version: `1.0.0`  
Mode: `full`  
Generated: `2026-10-22T16:13:19Z`

## Checks

| Check | Result | Detail |
|---|---:|---|
| version and citation identity | **PASS** | pyproject, runtime, and citation identify 1.0.0 |
| repository publication layout | **PASS** | 16 publication-facing files present |
| archive path safety | **PASS** | all source-tree paths are archive safe |
| strict research API contract | **PASS** | strict API passed |
| strict expanded API contract | **PASS** | expanded API passed |
| strict stable API contract | **PASS** | stable API passed |
| stable verification suite | **PASS** | 6/6 |
| typed-expression verification suite | **PASS** | 47/47 |
| current release contract | **PASS** | release contract passed |
| cross-version upgrade contract | **PASS** | upgrade contract passed |
| historical platform record integrity (not current qualification) | **PASS** | historical record integrity passed; external promotion required |
| source-stage contract readiness (external promotion required) | **PASS** | source contract passed; external promotion required |
| deterministic public capability tour | **PASS** | capability record de5bd3d1d04ae359baf83105807acaeb9581887cde5806823d9aae17c882c246 |
| local documentation links | **PASS** | all local Markdown links resolve |
| current distribution parity and executable modes | **PASS** | 1.0.0: 392 source files match both distributions, wheel RECORD and shell modes pass |
| strict MkDocs build | **PASS** | strict MkDocs build passed |
| complete source test suite | **PASS** | 2752 passed, 7 skipped, 6 warnings in 121.02s (0:02:01) |
| source and artifact snapshot unchanged during qualification | **PASS** | 90f5af7eb8264c50840f7ab1bf4e440a252fb5ada9a4291c5be80d696cd14cea |

## Non-gating warnings

- This source/publication gate checks historical platform-record integrity only. Current candidate CPU/GPU qualification requires release_promotion.py.
- Installed-artifact behavior was not executed; use --installed-artifacts or release_artifact_gate.py.

## Public capability tour

Record digest: `de5bd3d1d04ae359baf83105807acaeb9581887cde5806823d9aae17c882c246`

The tour covers polyphase refinement, redundant analysis and synthesis, Euler–Fibonacci coordinates, exact finite integration, typed expressions, portable persistence, and the frozen stable API manifest.

## Full source tests

- Return code: `0`
- Summary: `2752 passed, 7 skipped, 6 warnings in 121.02s (0:02:01)`

Report SHA-256: `0e0c81b7d97441d87fcce783c0c67daa27b8d8eeceee709200a583eac1403a18`
