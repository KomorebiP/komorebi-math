# Release Verification

Status: **PASSED**

Package version: `1.0.0`  
Mode: `full`  
Generated: `2026-10-22T16:01:34Z`

## Checks

| Check | Result | Detail |
|---|---:|---|
| version and citation identity | **PASS** | pyproject, runtime, and citation identify 1.0.0 |
| repository publication layout | **PASS** | 16 publication-facing files present |
| archive path safety | **PASS** | all source-tree paths are archive safe |
| strict research API contract | **PASS** | strict API passed |
| strict expanded API contract | **PASS** | expanded API passed |
| strict stable API contract | **PASS** | stable API passed |
| stable verification suite | **PASS** | 6/6 |
| typed-expression verification suite | **PASS** | 47/47 |
| current release contract | **PASS** | release contract passed |
| cross-version upgrade contract | **PASS** | upgrade contract passed |
| historical platform record integrity (not current qualification) | **PASS** | historical record integrity passed; external promotion required |
| source-stage contract readiness (external promotion required) | **PASS** | source contract passed; external promotion required |
| deterministic public capability tour | **PASS** | capability record de5bd3d1d04ae359baf83105807acaeb9581887cde5806823d9aae17c882c246 |
| local documentation links | **PASS** | all local Markdown links resolve |
| current distribution parity and executable modes | **PASS** | 1.0.0: 392 source files match both distributions, wheel RECORD and shell modes pass |
| strict MkDocs build | **PASS** | strict MkDocs build passed |
| complete source test suite | **PASS** | 2752 passed, 7 skipped, 6 warnings in 112.72s (0:01:52) |
| source and artifact snapshot unchanged during qualification | **PASS** | 0ffae94e151b0506c3b1122b52d88b042fb54fa98bde7cf6044ecd8bc4d576ed |

## Non-gating warnings

- This source/publication gate checks historical platform-record integrity only. Current candidate CPU/GPU qualification requires release_promotion.py.
- Installed-artifact behavior was not executed; use --installed-artifacts or release_artifact_gate.py.

## Public capability tour

Record digest: `de5bd3d1d04ae359baf83105807acaeb9581887cde5806823d9aae17c882c246`

The tour covers polyphase refinement, redundant analysis and synthesis, Euler–Fibonacci coordinates, exact finite integration, typed expressions, portable persistence, and the frozen stable API manifest.

## Full source tests

- Return code: `0`
- Summary: `2752 passed, 7 skipped, 6 warnings in 112.72s (0:01:52)`

Report SHA-256: `d13c90683550fb1154372c6b394aa20e409c8da29585db11ef286c38063f6414`
