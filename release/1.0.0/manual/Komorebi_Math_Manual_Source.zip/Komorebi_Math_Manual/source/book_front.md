# Preface {.unnumbered #preface}

Komorebi Math turns finite constructions of Realization Calculus into Python objects that can be inspected, combined and tested. Operators act on specified spaces. Coordinates describe the same finite data in different forms. Packets organize projections, transfers and refinements. Certificates record what a computation established and the assumptions under which it did so.

This manual follows that working language from installation to complete mathematical programs. It begins with small calculations and the stable interface, then develops coordinates, arithmetic, signals, nonlinear calculus, integration and finite quantum models. Later chapters explain how to preserve and exchange results. The reference appendices collect the broader interfaces, operating requirements and maintainer procedures.

The distinction between exact arithmetic, numerical evidence and conditional conclusions is part of the mathematics of the library. A finite calculation establishes a statement about its supplied objects under its stated rules. A saved record preserves that evidence; a fresh validity claim requires the relevant operation to be run again. The chapters explain these boundaries where they matter to the calculation.

## Reading and running the examples {.unnumbered}

Begin with the installation and first programs, then follow the subject that matches the problem at hand. The final worked-calculation chapter brings several domains together through examples with independent controls. The glossary explains the recurring language of realizations, packets, coordinates, residuals and certificates.

Code listings distinguish independently executable Python examples from interface sketches and contextual fragments. A sketch shows an API or a formula and may rely on objects defined in the surrounding discussion. Shell commands assume the working directory and environment stated in their section. Expected output is shown separately from the program that produces it.

The executable Python examples run with assertions enabled. Dependencies and finite input conventions are stated alongside the examples. Optional GPU workflows and external LaTeX compilation require their own environments; a successful CPU example does not qualify those runtimes.

Printed cross-references give section numbers and remain clickable in the PDF. File and script names in commands are literal. API identifiers retain their exact Python spelling.
