from pathlib import Path
import copy,hashlib,json,re,subprocess,sys
HERE=Path(__file__).resolve().parent;BASE=HERE.parent;BUILD=BASE/'build';DOCS=HERE/'docs'; BUILD.mkdir(exist_ok=True);(BASE/'review').mkdir(exist_ok=True)
PROFILE=HERE/'manual_example_profile.json'
PARTS=[
('Using the library','A calculation begins with a choice of objects, arithmetic and evidence. These chapters establish the working environment and the common language used throughout the manual.',[
 ('First calculations',['USER_GUIDE.md']),('The stable interface',['STABLE_API.md']),('The executable language',['UNIFIED_LANGUAGE.md'])]),
('Operators and coordinates','Coordinate maps, packet decompositions and transfer operators describe finite data through compatible representations. Their reconstruction laws determine what can be moved, compared and recovered.',[
 ('Coordinate systems and recurrence models',['GENERAL_COORDINATE_ATLAS.md','COMPANION_COORDINATE_CALCULUS.md']),('Analysis and synthesis',['ANALYSIS_SYNTHESIS_SYSTEMS.md']),('Redundant frames',['REDUNDANT_FRAME_ALGEBRA.md']),('Metric packets',['METRIC_PACKETS.md']),('Distortion cocycles',['DISTORTION_COCYCLES.md']),('Convex packets',['CONVEX_PACKETS.md'])]),
('Arithmetic, functions and signals','The same finite working language reaches recurrences, generating functions and signal decompositions. Each construction retains its own scalar conventions, admissible inputs and reconstruction conditions.',[
 ('Sequences and local comparisons',['sequences_oeis.md']),('Normalized generating functions',['NORMALIZED_GENERATING_FUNCTIONS.md']),('Special functions',['special_functions.md']),('Positive quadratic-form tails',['quadratic_forms.md']),('Finite join quotients',['finite_join_semilattice.md']),('Signal processing and recovery',['PRODUCTION_SIGNAL_PROCESSING.md','fourier_recovery.md','POLYPHASE_ROUTE_PACKETS.md','CARRIER_CHANGE_OBSTRUCTIONS.md','HANKEL_FALSIFICATION.md'])]),
('Nonlinear calculus and integration','Derivatives, jets, finite measures and typed expressions organize more elaborate calculations. Exact algebraic identities remain distinct from sampled numerical checks and assumptions supplied by the caller.',[
 ('Nonlinear calculus',['NONLINEAR_CALCULUS.md']),('Scalable nonlinear execution',['SCALABLE_NONLINEAR_EXECUTION.md']),('Streamed packet jets',['STREAMING_PACKET_JETS.md']),('Finite measures and integration',['FINITE_MEASURE_INTEGRATION.md','EXACT_INTEGRATION_EXAMPLE.md']),('Typed finite expressions',['TYPED_FINITE_EXPRESSION_CALCULUS.md','TYPED_EXPRESSION_EXAMPLE.md']),('Finite carrier completion',['FINITE_CARRIER_COMPLETION.md'])]),
('Models, portable results and complete programs','Finite quantum models provide another setting for operators and packets. Persistence and export make calculations usable beyond one interpreter, while complete programs show how the mathematical checks fit together.',[
 ('Quantum and memory models',['QUANTUM_MEMORY_NUMERICAL_CONTRACTS.md','dirac_modes.md']),('Portable persistence',['PERSISTENCE_SCHEMAS.md']),('Export and LaTeX',['EXPORT_AND_LATEX.md']),('Behavioral fixtures and profiling',['BEHAVIORAL_GOLDEN_AND_PROFILING.md']),('Extensions and companion C integration',['EXTENSION_API.md','COMPANION_C_INTEGRATION.md']),('Worked calculations and independent controls',['WORKED_EXAMPLES.md'])])]
APPENDICES=[('Public API reference',['PUBLIC_API.md']),('Thematic API inventory',['API_INVENTORY.md']),('Platforms, backends and PowerShell',['SUPPORTED_PLATFORMS.md','OPTIONAL_BACKEND_ISOLATION.md','GPU_INSTALLATION.md','GPU_VALIDATION.md','POWERSHELL_TESTS.md']),('Upgrading applications',['MIGRATION_TO_1_0.md','DEPRECATION_POLICY.md']),('Reproducibility and qualification',['RELEASE_PROCESS.md'])]

def parse(path):
 p=subprocess.run(['pandoc','-f','markdown+tex_math_single_backslash+tex_math_dollars+raw_tex','-t','json',str(path)],capture_output=True,text=True,check=True);return json.loads(p.stdout)
def text(s):return [{'t':'Str','c':s}]
def plain(inlines):
 return ''.join(x.get('c','') if x['t']=='Str' else ' ' if x['t'] in ('Space','SoftBreak','LineBreak') else plain(x['c']) if x['t'] in ('Emph','Strong','SmallCaps') else x['c'][1] if x['t']=='Code' else '' for x in inlines)
def esc(s):
 return ''.join({'\\':r'\textbackslash{}','{':r'\{','}':r'\}','_':r'\_','%':r'\%','&':r'\&','#':r'\#','$':r'\$','^':r'\textasciicircum{}','~':r'\textasciitilde{}'}.get(c,c) for c in s)
def raw(s):return {'t':'RawBlock','c':['latex',s]}

def slug(s):return re.sub('[^a-z0-9]+','-',s.lower()).strip('-')
files=[f for _,_,chs in PARTS for _,fs in chs for f in fs]+[f for _,fs in APPENDICES for f in fs]+['index.md']
assert len(files)==len(set(files))==47
assert set(files)==set(p.name for p in DOCS.glob('*.md'))
profile=json.loads(PROFILE.read_text());profiles=profile['sources']
asts={f:parse(DOCS/f) for f in files}; front=parse(HERE/'book_front.md'); glossary=parse(HERE/'glossary.md')
idmap={}; anchors={}; titlemap={}; document_records=[]
chapters=[(title,fs) for _,_,chs in PARTS for title,fs in chs]+APPENDICES
for title,fs in chapters:
 for j,f in enumerate(fs):
  key=slug(f[:-3]);titlemap[f]=title if j==0 else plain(asts[f]['blocks'][0]['c'][2]);anchors[f]=key
  for block in asts[f]['blocks']:
   if block['t']=='Header':
    old=block['c'][1][0];idmap[(f,old)]=key if block['c'][0]==1 else key+'--'+old
anchors['index.md']='reading-guide';titlemap['index.md']='Paths through the manual';anchors['README.md']='preface';anchors['PROJECT_README.md']='preface'
links=[];code_inventory=[];math_inventory=[]

def transform(node,filename):
 if isinstance(node,list):return [transform(v,filename) for v in node]
 if not isinstance(node,dict):return node
 typ=node.get('t');c=node.get('c')
 if typ=='Link':
  attr,label,target=c;url=target[0];name,sep,frag=url.partition('#');base=Path(name).name if name else filename
  if (not name or name.endswith('.md')) and base in anchors:
   label=transform(label,filename); label=plain(label) or titlemap.get(base,base)
   dest=idmap.get((base,frag),anchors[base]) if frag else anchors[base]
   links.append({'source':filename,'target':url,'resolved':dest})
   return {'t':'RawInline','c':['latex',r'\hyperref['+dest+']{'+esc(label)+r'} (\S\,\ref{'+dest+'})']}
  if not re.match(r'^[a-z]+:|^#',url):
   target[0]='https://github.com/KomorebiP/komorebi-math/blob/5f2b7ddc879c12d2bb00cbe5c487aa0bc7709222/'+('docs/'+name if not name.startswith('../') else name[3:])
 if typ=='Code':
  value=c[1]
  if value in anchors and value.endswith('.md'):
   dest=anchors[value];return {'t':'RawInline','c':['latex',r'\hyperref['+dest+']{'+esc(titlemap[value])+r'} (\S\,\ref{'+dest+'})']}
  if not any(x in value for x in ['\n','{','}']):
   pieces=re.split(r'(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])',value)
   tex=r'\allowbreak{}'.join(esc(piece) for piece in pieces).replace(r'\_',r'\_\allowbreak{}')
   for separator in ['.', '/', ',', '=', '+', '-', '*', '(', ')']:
    tex=tex.replace(separator,separator+r'\allowbreak{}')
   return {'t':'RawInline','c':['latex',r'\codeword{'+tex+'}']}
 if typ=='Str':
  # Text-only Unicode normalization for fonts; code and math are untouched.
  mp={'→':r'\(\to\)','←':r'\(\leftarrow\)','↔':r'\(\leftrightarrow\)','≥':r'\(\ge\)','≤':r'\(\le\)','≠':r'\(\ne\)','ℤ':r'\(\mathbb Z\)','ℚ':r'\(\mathbb Q\)','ℝ':r'\(\mathbb R\)'}
  if any(x in c for x in mp):
   return {'t':'RawInline','c':['latex',''.join(mp.get(x,esc(x)) for x in c)]}
 if typ=='Math':math_inventory.append({'source':filename,'kind':c[0]['t'],'sha256':hashlib.sha256(c[1].encode()).hexdigest()});return node
 return {k:transform(v,filename) for k,v in node.items()}

def section_blocks(filename,chapter_title=None,merge=False):
 key=anchors[filename];ast=copy.deepcopy(asts[filename]);blocks=ast['blocks'];out=[];pyindex=0;fenceindex=0
 excludes={x['example']:x['reason'] for x in profiles.get('docs/'+filename,{}).get('exclude',[])}
 for bi,b in enumerate(blocks):
  if filename=='USER_GUIDE.md' and b['t']=='Header' and plain(b['c'][2])=='Exact coordinate changes':
   out.append(raw(r'\begin{figure}[H]\centering\includegraphics[width=0.65\textwidth]{figures/packet_decomposition.pdf}\caption{Two coordinate projectors decompose the vector into its horizontal and vertical packets. Their sum reconstructs the original vector.}\end{figure}'))
  if b['t']=='Para' and bi+1<len(blocks) and blocks[bi+1]['t']=='CodeBlock':
   lines=blocks[bi+1]['c'][1].count('\n')+1
   points=(min(lines,12)*11.1+70) if lines<=12 else 120
   out.append(raw(r'\Needspace{'+str(points)+'pt}'))
  if b['t']=='Table':
   rows=sum(len(x[2])+len(x[3]) for x in b['c'][4])
   if rows<=5:out.append(raw(r'\Needspace{'+str(rows*2.5+4)+r'\baselineskip}'))
  if b['t']=='Header':
   near=blocks[bi+1:bi+3]
   following=next((item for item in near if item['t']=='CodeBlock'),None)
   if following is not None:
    lines=following['c'][1].count('\n')+1
    out.append(raw(r'\Needspace{'+str(min(lines,12)*11.1+(150 if near and near[0]['t']=='Para' else 90))+'pt}'))
   elif near and near[0]['t']=='Table':
    rows=sum(len(x[2])+len(x[3]) for x in near[0]['c'][4])
    if rows<=5:out.append(raw(r'\Needspace{'+str(rows*2.5+6)+r'\baselineskip}'))
   level,attr,inlines=b['c'];old=attr[0];attr[0]=idmap[(filename,old)]
   if inlines and inlines[0]['t']=='Str':
    if re.fullmatch(r'\d+[.)]',inlines[0]['c']):
     inlines=inlines[2:] if len(inlines)>1 and inlines[1]['t']=='Space' else inlines[1:]
   if level==1:
    if chapter_title:inlines=text(chapter_title)
    level=2 if merge else 1
   else:level=min(level+1 if merge else level,5)
   b['c']=[level,attr,inlines]
   if filename=='STREAMING_PACKET_JETS.md' and plain(inlines)=='Two write modes':out.append(raw(r'\Needspace{330pt}'))
   if filename=='WORKED_EXAMPLES.md' and level==2 and plain(inlines)=='Positive quadratic-form tails':
    out.append(raw(r'\Needspace{14\baselineskip}'))
  if b['t']=='CodeBlock':
   fenceindex+=1;classes=b['c'][0][1];lang=classes[0] if classes else 'text';program=b['c'][1]
   if lang in ('python','py','python3'):
    pyindex+=1;kind='Contextual fragment' if pyindex in excludes else 'Executable example';label='PYTHON  |  '+kind
   else:kind='command' if lang in ('bash','sh','powershell','ps1') else 'output';label={'bash':'SHELL','sh':'SHELL','powershell':'POWERSHELL','ps1':'POWERSHELL','text':'OUTPUT','json':'JSON'}.get(lang,lang.upper())
   small=program.count('\n')+1<=12
   if small:
    out.append(raw(r'\Needspace{'+str((program.count('\n')+1)*11.1+45)+'pt}'))
    out.append(raw(r'\begingroup\tcbset{manualcode/.append style={breakable=false}}'))
   out.append(raw(r'\listinglabel{'+esc(label)+'}'))
   code_inventory.append({'source':filename,'fence':fenceindex,'python_example':pyindex if lang in ('python','py','python3') else None,'language':lang,'scope':kind,'reason':excludes.get(pyindex) if lang in ('python','py','python3') else None,'sha256':hashlib.sha256(program.encode()).hexdigest()})
  out.append(transform(b,filename))
  if b['t']=='CodeBlock' and b['c'][1].count('\n')+1<=12:out.append(raw(r'\endgroup'))
 if filename=='ANALYSIS_SYNTHESIS_SYSTEMS.md':
  out.append(raw(r'''\section{An explicit redundant coordinate space}
For an analysis map from two coordinates to three, take
\[
T=\begin{pmatrix}1&0\\0&1\\1&1\end{pmatrix},\qquad
S=\frac13\begin{pmatrix}2&-1&1\\-1&2&1\end{pmatrix}.
\]
Then \(ST=I_2\), while \(TS\) is the projection onto the range of \(T\).
Synthesis reconstructs every object in the two-dimensional space. Coordinate roundtrip retains only triples consistent with the analysis relation.
\begin{figure}[H]\centering\includegraphics[width=\textwidth]{figures/analysis_synthesis.pdf}\caption{Object reconstruction is the identity. In the larger coordinate space, the roundtrip is an idempotent projection rather than the full identity.}\end{figure}'''))
 document_records.append({'source':filename,'chapter_title':chapter_title or titlemap[filename],'anchor':key,'python_fences':pyindex})
 return out

body=front['blocks'];body.append({'t':'Header','c':[1,['reading-guide',['unnumbered'],[]],text('Paths through the manual')]})
# Condense the web landing page into a single print navigation page.
body.append({'t':'Para','c':text('Choose a subject from the table, then follow the numbered cross-references. The opening chapters establish installation and certificate semantics. The appendices collect reference material and operating requirements.')})
for b in copy.deepcopy(asts['index.md']['blocks']):
 if b['t']=='Table':body.append(transform(b,'index.md'))
body.append({'t':'Para','c':text('For complete programs with independent controls, turn to the worked-calculation chapter. For interface details, use the public API reference and thematic inventory. The glossary gathers the recurring mathematical and software terms.')})
body.append(raw(r'\mainmatter'))
for part,intro,chapters_in_part in PARTS:
 body.append(raw(r'\manualpart{'+esc(part)+'}{'+esc(intro)+'}'))
 for title,fs in chapters_in_part:
  for j,f in enumerate(fs):body.extend(section_blocks(f,title if j==0 else None,merge=j>0))
body.append(raw(r'\appendix\fontsize{10}{12.2}\selectfont\setlength{\parskip}{4pt}'))
for title,fs in APPENDICES:
 for j,f in enumerate(fs):
  bs=section_blocks(f,title if j==0 else None,merge=j>0)
  if f=='API_INVENTORY.md':
   # Compact the navigation inventory while retaining each named entry.
   bs=[bs[0],raw(r'\begin{multicols}{2}\raggedright\footnotesize')]+bs[1:]+[raw(r'\end{multicols}')]
  body.extend(bs)
body.extend(glossary['blocks'])
book={'pandoc-api-version':front['pandoc-api-version'],'meta':{},'blocks':body}
(BUILD/'manual.json').write_text(json.dumps(book,ensure_ascii=False))
manifest={'title':'Komorebi Math: The Python Library','author':'Komorebi P.','source_commit':'5f2b7ddc879c12d2bb00cbe5c487aa0bc7709222','source_guides':47,'chapters':27,'appendices':6,'document_records':document_records,'code_listings':code_inventory,'mathematical_spans':math_inventory,'internal_links':links}
(BASE/'review/book_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
subprocess.run(['pandoc',str(BUILD/'manual.json'),'-f','json','-t','latex','--standalone','--template',str(HERE/'book.tex'),'--top-level-division=chapter','--number-sections','--highlight-style','tango','--wrap=none','-o',str(BUILD/'Komorebi_Math_Manual.tex')],check=True,cwd=HERE)
# Fit two long mathematical chains without changing their tokens.
tex_path=BUILD/'Komorebi_Math_Manual.tex';tex=tex_path.read_text()
for marker in [r'\text{conditioning envelope}',r'\text{arbitrary symmetric convex packet}']:
 pattern=r'\\\[\n(.*?)\n\\\]'
 for match in list(re.finditer(pattern,tex,re.S)):
  expression=match.group(1)
  if marker in expression:
   replacement='\\[\n'+r'\resizebox{\linewidth}{!}{$\displaystyle '+expression+'$}\n'+r'\]'
   tex=tex.replace(match.group(0),replacement)
tex_path.write_text(tex)
print('Assembled47 guides,27 chapters,6appendices;',len(code_inventory),'code listings;',len(math_inventory),'source math spans')
