"""Verify code and mathematical tokens against frozen source digests."""
from pathlib import Path
import hashlib,json,re,subprocess
HERE=Path(__file__).resolve().parent;BASE=HERE.parent

def fences(s):
 rows=[];opening=None;body=[]
 for line in s.splitlines(keepends=True):
  if opening is None:
   match=re.fullmatch(r' {0,3}(`{3,}|~{3,})([^\r\n]*)[\r\n]*',line)
   if match:opening=match.groups();body=[]
  elif re.fullmatch(r' {0,3}'+re.escape(opening[0][0])+'{'+str(len(opening[0]))+r',}[ \t]*[\r\n]*',line):
   rows.append((opening[1],''.join(body)));opening=None
  else:body.append(line)
 if opening is not None:raise ValueError('Unclosed code fence')
 return rows

def maths(p):
 d=json.loads(subprocess.check_output(['pandoc','-f','markdown+tex_math_single_backslash+tex_math_dollars+raw_tex','-t','json',str(p)]));result=[]
 def walk(x):
  if isinstance(x,dict):
   if x.get('t')=='Math':result.append(x['c'])
   else:
    for item in x.values():walk(item)
  elif isinstance(x,list):
   for item in x:walk(item)
 walk(d['blocks']);return result

def digest(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()

def main():
 baseline=json.loads((HERE/'baseline_digests.json').read_text());rows=[]
 for name,old in sorted(baseline['files'].items()):
  p=HERE/'docs'/name;f=fences(p.read_text());m=maths(p)
  assert digest(f)==old['fence_sha256'],name+' code changed'
  assert digest(m)==old['math_sha256'],name+' mathematical tokens changed'
  current=hashlib.sha256(p.read_bytes()).hexdigest()
  rows.append({'file':name,'edited':current!=old['source_sha256'],'source_sha256':old['source_sha256'],'manual_sha256':current,'fenced_listings':len(f),'math_spans':len(m),'code_preserved':True,'math_preserved':True})
 report={'passed':True,'source_commit':baseline['source_commit'],'guides':len(rows),'edited_guides':sum(x['edited'] for x in rows),'fenced_listings':sum(x['fenced_listings'] for x in rows),'math_spans':sum(x['math_spans'] for x in rows),'files':rows}
 (BASE/'review').mkdir(exist_ok=True);(BASE/'review/PRESERVATION_AUDIT.json').write_text(json.dumps(report,indent=2)+'\n');print({k:v for k,v in report.items() if k!='files'})
if __name__=='__main__':main()
