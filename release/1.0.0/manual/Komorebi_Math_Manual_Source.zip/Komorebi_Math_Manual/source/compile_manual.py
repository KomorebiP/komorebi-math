"""Build the manual with stable relative paths and resolved cross-references."""
from pathlib import Path
import shutil,subprocess,sys
HERE=Path(__file__).resolve().parent;BASE=HERE.parent;BUILD=BASE/'build';BUILD.mkdir(exist_ok=True)
subprocess.run([sys.executable,str(HERE/'build_manual.py')],cwd=HERE,check=True)
for number in range(1,4):
 with (BUILD/f'final_pass_{number}.log').open('w') as log:
  result=subprocess.run(['xelatex','-interaction=nonstopmode','-halt-on-error','-output-directory',str(BUILD),str(BUILD/'Komorebi_Math_Manual.tex')],cwd=HERE,stdout=log,stderr=subprocess.STDOUT)
 if result.returncode:raise SystemExit(f'XeLaTeX pass {number} failed; see {BUILD/f"final_pass_{number}.log"}')
out=BASE/'output/pdf';out.mkdir(parents=True,exist_ok=True);shutil.copy2(BUILD/'Komorebi_Math_Manual.pdf',out/'Komorebi_Math_Manual.pdf')
print(out/'Komorebi_Math_Manual.pdf')
