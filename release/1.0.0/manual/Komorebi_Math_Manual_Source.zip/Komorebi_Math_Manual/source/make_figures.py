from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from fractions import Fraction
OUT=Path(__file__).resolve().parent/'figures';OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#26394a','text.color':'#26394a','axes.edgecolor':'#9aabb6','savefig.bbox':'tight'})
fig,ax=plt.subplots(figsize=(6.05,3.35));ax.set_aspect('equal');ax.set_xlim(-.4,3.4);ax.set_ylim(-.3,3.7)
for v,color,label in [((2,0),'#407e88',r'$P_1x=(2,0)$'),((0,3),'#9a6c35',r'$P_2x=(0,3)$'),((2,3),'#26394a',r'$x=(2,3)$')]:
 ax.annotate('',xy=v,xytext=(0,0),arrowprops=dict(arrowstyle='-|>',lw=2.1,color=color,mutation_scale=13))
ax.plot([2,2],[0,3],ls=':',color='#9aabb6');ax.plot([0,2],[3,3],ls=':',color='#9aabb6')
ax.text(2.13,3.04,r'$x=P_1x+P_2x$',fontsize=11);ax.text(1.6,-.27,r'$P_1x$',color='#407e88');ax.text(-.25,3.24,r'$P_2x$',color='#9a6c35');ax.set_xticks([0,1,2,3]);ax.set_yticks([0,1,2,3]);ax.set_xlabel('First coordinate');ax.set_ylabel('Second coordinate');ax.grid(alpha=.13);fig.tight_layout();fig.savefig(OUT/'packet_decomposition.pdf');plt.close(fig)
T=np.array([[1.,0.],[0.,1.],[1.,1.]]);S=np.array([[2.,-1.,1.],[-1.,2.,1.]])/3
assert np.allclose(S@T,np.eye(2));assert np.allclose((T@S)@(T@S),T@S)
fig,axes=plt.subplots(1,2,figsize=(6.05,2.8),gridspec_kw={'width_ratios':[2,3]})
for ax,M,title in zip(axes,[S@T,T@S],[r'$ST=I_2$',r'$TS$: projection onto the analysis range']):
 ax.imshow(M,vmin=-1,vmax=1,cmap='BrBG');n=M.shape[0]
 for i in range(n):
  for j in range(n):
   q=Fraction(float(M[i,j])).limit_denominator(3);s=str(q.numerator) if q.denominator==1 else f'{q.numerator}/{q.denominator}'
   ax.text(j,i,s,ha='center',va='center',fontsize=12,color='#ffffff' if abs(M[i,j])>.85 else '#233646')
 ax.set_title(title,fontsize=10,pad=12);ax.set_xticks(range(n));ax.set_xticklabels(range(1,n+1));ax.set_yticks(range(n));ax.set_yticklabels(range(1,n+1));ax.tick_params(length=0)
 for spine in ax.spines.values():spine.set_visible(False)
fig.tight_layout(w_pad=3);fig.savefig(OUT/'analysis_synthesis.pdf');plt.close(fig)
print('Two exact finite illustrations generated')
