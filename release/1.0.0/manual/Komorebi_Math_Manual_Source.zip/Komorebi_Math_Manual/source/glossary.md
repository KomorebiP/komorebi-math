# Glossary {#glossary}

The terms below describe how the library represents and checks finite mathematical objects. Their precise hypotheses and arithmetic rules are given in the relevant chapters.

| Term | Meaning in this manual |
| --- | --- |
| Analysis | A map from a represented object into a chosen coordinate space. |
| Arithmetic domain | The scalar rules used by a computation, such as integers, rational numbers, a finite field or floating point. |
| Certificate | A record of validity, evidence class, residuals and assumptions produced by a specified operation. |
| Codec | A declared representation and reconstruction rule for a portable object, with an identity and schema version. |
| Conditional result | A conclusion that retains assumptions not established by the computation. |
| Coordinate transform | A map between finite descriptions of data. Invertibility requires its own hypotheses or diagnostics. |
| Defect | A measured or exact failure of a stated identity, recurrence, compatibility condition or lifting equation. |
| Directed enclosure | Bounds computed with outward arithmetic under an explicitly stated arithmetic backend and trust model. |
| Exact result | A finite statement established using the producer's declared exact arithmetic and hypotheses. |
| Finite carrier | The explicitly represented finite space or data structure on which an operation is defined. |
| Grammar | A specification of legal objects, arrows and operator paths, together with the relations required by a realization. |
| Independent control | A comparison based on a separate formula or construction; its own arithmetic assumptions remain relevant. |
| Normal form | A canonical finite representation used to compare terms within a specified expression language. |
| Numerical result | A floating computation assessed by a stated residual, tolerance or error rule. |
| Obstruction | A condition that prevents a specified lift, compatibility relation or completion from being achieved. |
| Packet | A component selected by the projections or decomposition rules of a particular construction. |
| Polyphase coordinates | A decomposition of a finite signal into residue classes of its sample indices. |
| Provenance | Information identifying the objects, assumptions and operation to which evidence belongs. |
| Realization | Concrete spaces and operators that implement a specified finite grammar and its relations. |
| Refinement | A change to a more detailed representation with specified compatibility maps and identities. |
| Residual | A producer-defined quantity used to assess a stated identity or approximation. A residual has meaning only with its comparison rule. |
| Stable API | The reviewed interface with the declared compatibility promise for application code. |
| Synthesis | A map from coordinates back to the represented object. In a redundant system, coordinate roundtrip need not be the identity. |
| Transfer | An operator or compatible map that transports information between represented components. |
| Typed expression | A term whose source and target coordinate spaces, operations and evaluation rules belong to a specified finite language. |

## License

Original text and software are distributed under the MIT License. Third-party components and separately supplied datasets retain their own notices and terms. The manual uses the library’s documented finite mathematical contracts.
