# GPU validation

The CUDA checks execute PyTorch and CuPy in separate child interpreters. If a
worker aborts, times out, fails to import or exits with a nonzero status, the
parent interpreter remains alive and records the failure.

For the package installed in the selected environment:

```bash
python -m komorebi_math verify gpu
```

## Checked computations

The PyTorch worker checks CUDA availability and evaluates a cubic directional
JVP at `2`, with value `8` and tangent `12`. It also checks a device matrix-vector
product with expected result `[14, 38, 62, 86]`.

The CuPy worker checks device availability, executes a device-resident
`PacketIR`, and compares the result with `[0, 1, 4, 6]` using Euclidean residual
norm at most `1e-12`.

These controls check finite computations in the recorded environment. They do
not establish GPU performance, complete stress coverage or compatibility
with every driver and framework build.

## Release records

The hardware producer verifies the installed wheel inventory before and after
execution, clears source-path overrides, records interpreter/device/runtime
versions and retains the nested worker results. Its temporary installation
uses the exact candidate wheel and inherits the selected host's CUDA runtimes.

Follow the [release guide](RELEASE_PROCESS.md#stress-and-hardware-qualification)
for that artifact-bound command. Keep the complete report, including failed
runs. The installed-package diagnostic checks the selected environment. The
release record additionally binds that execution to exact distribution files.
