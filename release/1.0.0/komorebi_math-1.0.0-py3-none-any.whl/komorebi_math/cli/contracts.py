"""Public verification routes and accepted compatibility aliases."""

VERIFICATION_SUITE_NAMES = (
    "core",
    "refinement",
    "nonlinear",
    "block2",
    "algorithms",
    "block3",
    "signals",
    "dynamics",
    "block4",
    "analytic",
    "quantum",
    "block5",
    "arithmetic",
    "sequences",
    "block6",
    "deformation",
    "langlands-local",
    "langlands-finite-image",
    "langlands-completion",
    "langlands",
    "block7",
    "export",
    "block8",
    "block9",
    "hardening",
    "block10",
    "streaming-beta",
    "block11",
    "dsp",
    "block12",
    "generating",
    "block13",
    "coordinates",
    "block14",
    "block15",
    "stable",
    "release",
    "gpu",
    "block16",
    "upgrade",
    "evidence",
    "documentation",
    "beta",
    "block17",
    "frame-algebra",
    "block18",
    "integration",
    "block19",
    "expression",
    "block20",
    "all",
    "streaming",
)

PUBLIC_VERIFICATION_SUITE_NAMES = tuple(
    name
    for name in VERIFICATION_SUITE_NAMES
    if not name.startswith("block") and name not in {"beta", "evidence", "streaming-beta"}
)

API_CONTRACT_MODES = ("research", "beta", "stable")

__all__ = ["API_CONTRACT_MODES", "VERIFICATION_SUITE_NAMES"]
