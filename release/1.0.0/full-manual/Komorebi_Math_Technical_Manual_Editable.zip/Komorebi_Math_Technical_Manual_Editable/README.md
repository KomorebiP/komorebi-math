# Komorebi Math: Technical Manual and Reference — editable manuscript

This compact editing pack contains the complete editable source of the verified 2,529-page edition of the technical manual by Komorebi P.: all 14 parts, 91 chapters and 15 appendices, including the extended API and research references. The book content is complete.

## Edit and rebuild

Edit `Komorebi_Math_Technical_Manual.tex`, the standalone flattened typesetting source. Then run:

```sh
python build.py
```

The script copies the edited TeX into `build/`, runs three XeLaTeX typesetting passes, then waits for explicit `xdvipdfmx` conversion to finish. The rebuilt PDF is `output/Komorebi_Math_Technical_Manual.pdf`. Errors stop the build; logs remain in `build/`.

`manuscript.md` is the complete editable Markdown reading source. It is included for text editing and reuse. This compact script builds the TeX directly; it does not convert Markdown edits into TeX. Use the full source bundle's assembly workflow for that conversion.

Install Python 3.10 or later and a TeX distribution with XeLaTeX, xdvipdfmx, fontspec, unicode-math, fvextra, tcolorbox, titlesec, fancyhdr, tocloft, longtable, bookmark, xurl, mdframed, enumitem and standard AMS/table packages. Install TeX Gyre Pagella and Heros, DejaVu Sans Mono and Latin Modern Math. These are the fonts used by the documented build. Pandoc is unnecessary for this standalone TeX rebuild.

## Provenance and full evidence

The TeX and Markdown are exact copies of the final reviewed sources. `MANIFEST.json` binds every file in this pack by size and SHA-256. `PROOFREADING_SUMMARY.json` records the scope and limits of the original editorial review; editing or rebuilding does not extend that qualification. Rebuilt layout and pagination can vary with fonts or TeX versions.

The canonical reading PDF and complete source/audit/evidence bundle are available in the [full-manual download directory](https://github.com/KomorebiP/komorebi-math/tree/codex/python-1.0.0-delivery-5f2b7dd/release/1.0.0/full-manual). The full bundle retains the preservation audits, editorial history, historical verification receipts and reference snapshots. This compact pack omits those separately preserved supplements and the PDF.

Original documentation and software use the MIT License. Third-party notices and separately supplied data terms remain applicable.
