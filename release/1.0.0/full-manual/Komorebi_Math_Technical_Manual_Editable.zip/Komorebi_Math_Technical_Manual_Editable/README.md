# Komorebi Math: Technical Manual and Reference

The complete editable source for the 2,569-page manual by Komorebi P. This archive includes the entire book, not an abridgment.

## Files

- `Komorebi_Math_Technical_Manual.tex`: standalone LaTeX for the complete book.
- `manuscript.md`: the assembled editable Markdown, including the reader guidance.
- `build.py`: a portable LaTeX build command.
- `PROOFREADING_SUMMARY.json`: the delivered edition and validation scope.
- `MANIFEST.json`: file sizes and SHA-256 hashes.
- `LICENSE`: the MIT License.

## Rebuild the PDF

Install Python 3.10 or later and a TeX distribution with XeLaTeX, xdvipdfmx, fontspec, unicode-math, fvextra, tcolorbox, titlesec, fancyhdr, tocloft, longtable and the standard AMS and table packages. The layout uses TeX Gyre Pagella or P052, TeX Gyre Heros or Nimbus Sans, DejaVu Sans Mono and Latin Modern Math.

Run this command from the extracted folder:

```sh
python build.py
```

The script compiles the `.tex` file directly, running three typesetting passes and synchronous PDF conversion. It does not convert `manuscript.md`. For a Markdown-based revision, use the complete source bundle and its `source/compile_manual.py` workflow. TeX and font versions can change pagination.

The complete source bundle also contains the manuscript parts, assembly scripts, historical reference sources and detailed review evidence. The PDF reading copy is supplied separately.

This revision improves the reading experience and retains the original displayed mathematics and code. One prose hypothesis in Section 53.3 was corrected following a focused spectral-dimension check. The revision does not change the software implementation, constitute a whole-book theorem audit or extend hardware qualification. See the summary for the scope of the checks performed.
