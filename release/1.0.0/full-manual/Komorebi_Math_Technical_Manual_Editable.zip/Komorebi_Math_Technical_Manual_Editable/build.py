"""Rebuild the complete standalone technical manual from its editable TeX."""
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
NAME = "Komorebi_Math_Technical_Manual"
BUILD = ROOT / "build"
OUTPUT = ROOT / "output"


def run_logged(command, log):
    with log.open("w", encoding="utf-8") as stream:
        try:
            subprocess.run(command, cwd=BUILD, stdout=stream,
                           stderr=subprocess.STDOUT, check=True)
        except subprocess.CalledProcessError:
            print("\n".join(log.read_text(errors="replace").splitlines()[-30:]),
                  file=sys.stderr)
            raise


def main():
    for binary in ("xelatex", "xdvipdfmx"):
        if shutil.which(binary) is None:
            raise SystemExit(f"Required build program is unavailable: {binary}")
    source = ROOT / f"{NAME}.tex"
    if not source.is_file():
        raise SystemExit(f"Missing editable TeX source: {source.name}")
    BUILD.mkdir(exist_ok=True)
    OUTPUT.mkdir(exist_ok=True)
    shutil.copy2(source, BUILD / source.name)
    for number in range(1, 4):
        run_logged(["xelatex", "-no-pdf", "-no-shell-escape",
                    "-interaction=nonstopmode", "-halt-on-error",
                    "-file-line-error", source.name],
                   BUILD / f"tex-pass-{number}.console.log")
        print(f"Typesetting pass {number} completed.", flush=True)
    pdf = OUTPUT / f"{NAME}.pdf"
    run_logged(["xdvipdfmx", "-o", str(pdf), f"{NAME}.xdv"],
               BUILD / "pdf-conversion.console.log")
    data = pdf.read_bytes()
    if not data.startswith(b"%PDF-") or b"%%EOF" not in data[-1024:]:
        raise SystemExit("PDF conversion returned an incomplete file.")
    print(f"Built {pdf} ({len(data):,} bytes).", flush=True)


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as error:
        raise SystemExit(error.returncode)
